// Powered by OnSpace.AI
import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons, Ionicons } from '@expo/vector-icons';
import { LineChart, BarChart } from 'react-native-chart-kit';
import { router } from 'expo-router';
import { getReportsData } from '../services/energyService';

const { width } = Dimensions.get('window');

const reportTabs = [
  { id: 'table', title: 'Table View', icon: 'table-chart' },
  { id: 'graph', title: 'Graph View', icon: 'show-chart' },
];

export default function Reports() {
  const [selectedTab, setSelectedTab] = useState('table');
  const [reportsData, setReportsData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await getReportsData();
        setReportsData(data);
      } catch (error) {
        console.error('Failed to fetch reports data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const chartConfig = {
    backgroundGradientFrom: '#1e3a8a',
    backgroundGradientTo: '#3b82f6',
    color: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`,
    strokeWidth: 2,
    barPercentage: 0.7,
    useShadowColorFromDataset: false,
  };

  const reportData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
    datasets: [
      {
        data: [120, 150, 180, 200, 160, 190],
        color: (opacity = 1) => `rgba(34, 197, 94, ${opacity})`,
        strokeWidth: 2,
      },
      {
        data: [80, 100, 120, 140, 110, 130],
        color: (opacity = 1) => `rgba(239, 68, 68, ${opacity})`,
        strokeWidth: 2,
      },
    ],
  };

  const tableData = [
    { date: '2025-01-01', consumption: '125.50 kWh', cost: '₹780.50', efficiency: '92%' },
    { date: '2025-01-02', consumption: '130.20 kWh', cost: '₹810.25', efficiency: '89%' },
    { date: '2025-01-03', consumption: '118.75 kWh', cost: '₹738.90', efficiency: '95%' },
    { date: '2025-01-04', consumption: '142.30 kWh', cost: '₹885.85', efficiency: '87%' },
    { date: '2025-01-05', consumption: '128.60 kWh', cost: '₹800.15', efficiency: '91%' },
  ];

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={['#0f172a', '#1e293b']} style={styles.gradient}>
          <View style={styles.loadingContainer}>
            <Text style={styles.loadingText}>Loading Reports...</Text>
          </View>
        </LinearGradient>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient colors={['#0f172a', '#1e293b']} style={styles.gradient}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <Ionicons name="arrow-back" size={24} color="#ffffff" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>History Reports</Text>
          <View style={styles.headerActions}>
            <TouchableOpacity style={styles.actionButton}>
              <MaterialIcons name="download" size={20} color="#ffffff" />
            </TouchableOpacity>
            <TouchableOpacity style={styles.actionButton}>
              <MaterialIcons name="filter-list" size={20} color="#ffffff" />
            </TouchableOpacity>
          </View>
        </View>

        <View style={styles.tabsContainer}>
          {reportTabs.map((tab) => (
            <TouchableOpacity
              key={tab.id}
              style={[
                styles.tabButton,
                selectedTab === tab.id && styles.tabButtonActive,
              ]}
              onPress={() => setSelectedTab(tab.id)}
            >
              <MaterialIcons
                name={tab.icon as any}
                size={16}
                color={selectedTab === tab.id ? '#ffffff' : '#94a3b8'}
              />
              <Text
                style={[
                  styles.tabText,
                  selectedTab === tab.id && styles.tabTextActive,
                ]}
              >
                {tab.title}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        <ScrollView contentContainerStyle={styles.scrollContent}>
          <View style={styles.filterContainer}>
            <View style={styles.filterRow}>
              <Text style={styles.filterLabel}>Date Range:</Text>
              <TouchableOpacity style={styles.filterButton}>
                <Text style={styles.filterButtonText}>Last 30 Days</Text>
                <MaterialIcons name="keyboard-arrow-down" size={16} color="#94a3b8" />
              </TouchableOpacity>
            </View>
            <View style={styles.filterRow}>
              <Text style={styles.filterLabel}>Device:</Text>
              <TouchableOpacity style={styles.filterButton}>
                <Text style={styles.filterButtonText}>All Meters</Text>
                <MaterialIcons name="keyboard-arrow-down" size={16} color="#94a3b8" />
              </TouchableOpacity>
            </View>
          </View>

          {selectedTab === 'table' ? (
            <View style={styles.tableContainer}>
              <View style={styles.tableHeader}>
                <Text style={styles.tableHeaderText}>Date</Text>
                <Text style={styles.tableHeaderText}>Consumption</Text>
                <Text style={styles.tableHeaderText}>Cost</Text>
                <Text style={styles.tableHeaderText}>Efficiency</Text>
              </View>
              {tableData.map((row, index) => (
                <View key={index} style={styles.tableRow}>
                  <Text style={styles.tableCell}>{row.date}</Text>
                  <Text style={styles.tableCell}>{row.consumption}</Text>
                  <Text style={styles.tableCell}>{row.cost}</Text>
                  <Text style={[styles.tableCell, styles.efficiencyCell]}>
                    {row.efficiency}
                  </Text>
                </View>
              ))}
            </View>
          ) : (
            <View style={styles.chartContainer}>
              <Text style={styles.chartTitle}>Energy Consumption & Cost Trends</Text>
              <LineChart
                data={reportData}
                width={width - 40}
                height={220}
                chartConfig={chartConfig}
                style={styles.chart}
                bezier
              />
              <View style={styles.chartLegend}>
                <View style={styles.legendItem}>
                  <View style={[styles.legendColor, { backgroundColor: '#22c55e' }]} />
                  <Text style={styles.legendText}>Consumption</Text>
                </View>
                <View style={styles.legendItem}>
                  <View style={[styles.legendColor, { backgroundColor: '#ef4444' }]} />
                  <Text style={styles.legendText}>Cost</Text>
                </View>
              </View>
            </View>
          )}

          <View style={styles.summaryContainer}>
            <View style={styles.summaryCard}>
              <MaterialIcons name="trending-up" size={32} color="#22c55e" />
              <View style={styles.summaryContent}>
                <Text style={styles.summaryTitle}>Total Consumption</Text>
                <Text style={styles.summaryValue}>1,247.85 kWh</Text>
                <Text style={styles.summaryChange}>+12.5% from last month</Text>
              </View>
            </View>
            <View style={styles.summaryCard}>
              <MaterialIcons name="account-balance-wallet" size={32} color="#3b82f6" />
              <View style={styles.summaryContent}>
                <Text style={styles.summaryTitle}>Total Cost</Text>
                <Text style={styles.summaryValue}>₹7,768.25</Text>
                <Text style={styles.summaryChange}>+8.3% from last month</Text>
              </View>
            </View>
          </View>
        </ScrollView>
      </LinearGradient>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  gradient: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#334155',
  },
  backButton: {
    padding: 8,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  headerActions: {
    flexDirection: 'row',
  },
  actionButton: {
    padding: 8,
    marginLeft: 8,
  },
  tabsContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  tabButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 8,
    marginRight: 12,
    backgroundColor: '#1e293b',
    borderRadius: 20,
  },
  tabButtonActive: {
    backgroundColor: '#3b82f6',
  },
  tabText: {
    fontSize: 12,
    color: '#94a3b8',
    marginLeft: 6,
  },
  tabTextActive: {
    color: '#ffffff',
  },
  scrollContent: {
    padding: 20,
  },
  filterContainer: {
    backgroundColor: '#1e293b',
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
  },
  filterRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  filterLabel: {
    fontSize: 12,
    color: '#94a3b8',
  },
  filterButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#374151',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 6,
  },
  filterButtonText: {
    fontSize: 12,
    color: '#ffffff',
    marginRight: 4,
  },
  tableContainer: {
    backgroundColor: '#1e293b',
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
  },
  tableHeader: {
    flexDirection: 'row',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#374151',
  },
  tableHeaderText: {
    flex: 1,
    fontSize: 12,
    fontWeight: '600',
    color: '#ffffff',
    textAlign: 'center',
  },
  tableRow: {
    flexDirection: 'row',
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: '#374151',
  },
  tableCell: {
    flex: 1,
    fontSize: 11,
    color: '#94a3b8',
    textAlign: 'center',
  },
  efficiencyCell: {
    color: '#22c55e',
  },
  chartContainer: {
    backgroundColor: '#1e293b',
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
  },
  chartTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#ffffff',
    marginBottom: 16,
    textAlign: 'center',
  },
  chart: {
    borderRadius: 8,
  },
  chartLegend: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 12,
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: 12,
  },
  legendColor: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 6,
  },
  legendText: {
    fontSize: 10,
    color: '#94a3b8',
  },
  summaryContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  summaryCard: {
    backgroundColor: '#1e293b',
    borderRadius: 12,
    padding: 16,
    width: (width - 60) / 2,
    flexDirection: 'row',
    alignItems: 'center',
  },
  summaryContent: {
    marginLeft: 12,
    flex: 1,
  },
  summaryTitle: {
    fontSize: 10,
    color: '#94a3b8',
    marginBottom: 4,
  },
  summaryValue: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#ffffff',
    marginBottom: 2,
  },
  summaryChange: {
    fontSize: 8,
    color: '#22c55e',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    fontSize: 16,
    color: '#ffffff',
  },
});