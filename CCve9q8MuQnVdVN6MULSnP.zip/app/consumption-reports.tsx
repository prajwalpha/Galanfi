// Powered by OnSpace.AI
import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Dimensions, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons, Ionicons } from '@expo/vector-icons';
import { LineChart, BarChart } from 'react-native-chart-kit';
import { router } from 'expo-router';
import { getConsumptionReports, downloadReport } from '../services/consumptionService';
import { ConsumptionReport, TimeInterval } from '../services/types';

const { width } = Dimensions.get('window');

const timeIntervals: { id: TimeInterval; label: string; icon: string }[] = [
  { id: '15min', label: '15 Min', icon: 'timer' },
  { id: '30min', label: '30 Min', icon: 'timer' },
  { id: '60min', label: '60 Min', icon: 'schedule' },
  { id: 'daily', label: 'Daily', icon: 'today' },
  { id: 'weekly', label: 'Weekly', icon: 'date-range' },
  { id: 'monthly', label: 'Monthly', icon: 'calendar-view-month' },
  { id: 'yearly', label: 'Yearly', icon: 'calendar-today' },
];

const downloadFormats = [
  { id: 'pdf', label: 'PDF', icon: 'picture-as-pdf', color: '#ef4444' },
  { id: 'excel', label: 'Excel', icon: 'table-chart', color: '#22c55e' },
  { id: 'csv', label: 'CSV', icon: 'description', color: '#3b82f6' },
];

export default function ConsumptionReports() {
  const [selectedInterval, setSelectedInterval] = useState<TimeInterval>('daily');
  const [reportData, setReportData] = useState<ConsumptionReport | null>(null);
  const [loading, setLoading] = useState(false);
  const [downloading, setDownloading] = useState(false);

  useEffect(() => {
    fetchReportData();
  }, [selectedInterval]);

  const fetchReportData = async () => {
    setLoading(true);
    try {
      const data = await getConsumptionReports(selectedInterval);
      setReportData(data);
    } catch (error) {
      console.error('Failed to fetch consumption reports:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDownload = async (format: string) => {
    setDownloading(true);
    try {
      await downloadReport(selectedInterval, format);
      Alert.alert('Success', `Report downloaded as ${format.toUpperCase()}`);
    } catch (error) {
      Alert.alert('Error', 'Failed to download report');
      console.error('Download error:', error);
    } finally {
      setDownloading(false);
    }
  };

  const chartConfig = {
    backgroundGradientFrom: '#1e3a8a',
    backgroundGradientTo: '#3b82f6',
    color: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`,
    strokeWidth: 2,
    barPercentage: 0.7,
    useShadowColorFromDataset: false,
  };

  const getChartData = () => {
    if (!reportData) return { labels: [], datasets: [] };
    
    return {
      labels: reportData.chartData.labels,
      datasets: [
        {
          data: reportData.chartData.consumption,
          color: (opacity = 1) => `rgba(34, 197, 94, ${opacity})`,
          strokeWidth: 2,
        },
      ],
    };
  };

  const getCostChartData = () => {
    if (!reportData) return { labels: [], datasets: [] };
    
    return {
      labels: reportData.chartData.labels,
      datasets: [
        {
          data: reportData.chartData.cost,
          color: (opacity = 1) => `rgba(239, 68, 68, ${opacity})`,
          strokeWidth: 2,
        },
      ],
    };
  };

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient colors={['#0f172a', '#1e293b']} style={styles.gradient}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <Ionicons name="arrow-back" size={24} color="#ffffff" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Consumption Reports</Text>
          <TouchableOpacity style={styles.refreshButton} onPress={fetchReportData}>
            <MaterialIcons name="refresh" size={24} color="#ffffff" />
          </TouchableOpacity>
        </View>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.intervalContainer}>
          {timeIntervals.map((interval) => (
            <TouchableOpacity
              key={interval.id}
              style={[
                styles.intervalButton,
                selectedInterval === interval.id && styles.intervalButtonActive,
              ]}
              onPress={() => setSelectedInterval(interval.id)}
            >
              <MaterialIcons
                name={interval.icon as any}
                size={16}
                color={selectedInterval === interval.id ? '#ffffff' : '#94a3b8'}
              />
              <Text
                style={[
                  styles.intervalText,
                  selectedInterval === interval.id && styles.intervalTextActive,
                ]}
              >
                {interval.label}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <ScrollView contentContainerStyle={styles.scrollContent}>
          {loading ? (
            <View style={styles.loadingContainer}>
              <Text style={styles.loadingText}>Loading {selectedInterval} reports...</Text>
            </View>
          ) : (
            reportData && (
              <>
                <View style={styles.summaryContainer}>
                  <View style={styles.summaryCard}>
                    <MaterialIcons name="flash-on" size={32} color="#22c55e" />
                    <View style={styles.summaryContent}>
                      <Text style={styles.summaryTitle}>Total Consumption</Text>
                      <Text style={styles.summaryValue}>{reportData.summary.totalConsumption.toFixed(2)} kWh</Text>
                      <Text style={styles.summaryChange}>
                        {reportData.summary.consumptionChange > 0 ? '+' : ''}
                        {reportData.summary.consumptionChange.toFixed(1)}% from previous period
                      </Text>
                    </View>
                  </View>
                  <View style={styles.summaryCard}>
                    <MaterialIcons name="account-balance-wallet" size={32} color="#3b82f6" />
                    <View style={styles.summaryContent}>
                      <Text style={styles.summaryTitle}>Total Cost</Text>
                      <Text style={styles.summaryValue}>₹{reportData.summary.totalCost.toFixed(2)}</Text>
                      <Text style={styles.summaryChange}>
                        {reportData.summary.costChange > 0 ? '+' : ''}
                        {reportData.summary.costChange.toFixed(1)}% from previous period
                      </Text>
                    </View>
                  </View>
                </View>

                <View style={styles.chartContainer}>
                  <Text style={styles.chartTitle}>Energy Consumption - {selectedInterval}</Text>
                  <LineChart
                    data={getChartData()}
                    width={width - 40}
                    height={220}
                    chartConfig={chartConfig}
                    style={styles.chart}
                    bezier
                  />
                  <View style={styles.chartLegend}>
                    <View style={styles.legendItem}>
                      <View style={[styles.legendColor, { backgroundColor: '#22c55e' }]} />
                      <Text style={styles.legendText}>Consumption (kWh)</Text>
                    </View>
                  </View>
                </View>

                <View style={styles.chartContainer}>
                  <Text style={styles.chartTitle}>Cost Analysis - {selectedInterval}</Text>
                  <BarChart
                    data={getCostChartData()}
                    width={width - 40}
                    height={220}
                    chartConfig={chartConfig}
                    style={styles.chart}
                  />
                  <View style={styles.chartLegend}>
                    <View style={styles.legendItem}>
                      <View style={[styles.legendColor, { backgroundColor: '#ef4444' }]} />
                      <Text style={styles.legendText}>Cost (₹)</Text>
                    </View>
                  </View>
                </View>

                <View style={styles.downloadContainer}>
                  <Text style={styles.downloadTitle}>Download Report</Text>
                  <View style={styles.downloadButtons}>
                    {downloadFormats.map((format) => (
                      <TouchableOpacity
                        key={format.id}
                        style={[styles.downloadButton, { backgroundColor: format.color }]}
                        onPress={() => handleDownload(format.id)}
                        disabled={downloading}
                      >
                        <MaterialIcons name={format.icon as any} size={20} color="#ffffff" />
                        <Text style={styles.downloadButtonText}>{format.label}</Text>
                      </TouchableOpacity>
                    ))}
                  </View>
                </View>

                <View style={styles.detailsContainer}>
                  <Text style={styles.detailsTitle}>Report Details</Text>
                  <View style={styles.detailItem}>
                    <Text style={styles.detailLabel}>Report Period:</Text>
                    <Text style={styles.detailValue}>{reportData.period}</Text>
                  </View>
                  <View style={styles.detailItem}>
                    <Text style={styles.detailLabel}>Data Points:</Text>
                    <Text style={styles.detailValue}>{reportData.dataPoints}</Text>
                  </View>
                  <View style={styles.detailItem}>
                    <Text style={styles.detailLabel}>Average Consumption:</Text>
                    <Text style={styles.detailValue}>{reportData.avgConsumption.toFixed(2)} kWh</Text>
                  </View>
                  <View style={styles.detailItem}>
                    <Text style={styles.detailLabel}>Peak Consumption:</Text>
                    <Text style={styles.detailValue}>{reportData.peakConsumption.toFixed(2)} kWh</Text>
                  </View>
                  <View style={styles.detailItem}>
                    <Text style={styles.detailLabel}>Average Cost per kWh:</Text>
                    <Text style={styles.detailValue}>₹{reportData.avgCostPerKwh.toFixed(2)}</Text>
                  </View>
                </View>
              </>
            )
          )}
        </ScrollView>
      </LinearGradient>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  gradient: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#334155',
  },
  backButton: {
    padding: 8,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  refreshButton: {
    padding: 8,
  },
  intervalContainer: {
    maxHeight: 60,
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  intervalButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 8,
    marginRight: 12,
    backgroundColor: '#1e293b',
    borderRadius: 20,
  },
  intervalButtonActive: {
    backgroundColor: '#3b82f6',
  },
  intervalText: {
    fontSize: 12,
    color: '#94a3b8',
    marginLeft: 6,
  },
  intervalTextActive: {
    color: '#ffffff',
  },
  scrollContent: {
    padding: 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 60,
  },
  loadingText: {
    fontSize: 16,
    color: '#94a3b8',
  },
  summaryContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  summaryCard: {
    backgroundColor: '#1e293b',
    borderRadius: 12,
    padding: 16,
    width: (width - 60) / 2,
    flexDirection: 'row',
    alignItems: 'center',
  },
  summaryContent: {
    marginLeft: 12,
    flex: 1,
  },
  summaryTitle: {
    fontSize: 10,
    color: '#94a3b8',
    marginBottom: 4,
  },
  summaryValue: {
    fontSize: 14,
    fontWeight: 'bold',
    color: '#ffffff',
    marginBottom: 2,
  },
  summaryChange: {
    fontSize: 8,
    color: '#22c55e',
  },
  chartContainer: {
    backgroundColor: '#1e293b',
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
  },
  chartTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#ffffff',
    marginBottom: 16,
    textAlign: 'center',
  },
  chart: {
    borderRadius: 8,
  },
  chartLegend: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 12,
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: 12,
  },
  legendColor: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 6,
  },
  legendText: {
    fontSize: 10,
    color: '#94a3b8',
  },
  downloadContainer: {
    backgroundColor: '#1e293b',
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
  },
  downloadTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#ffffff',
    marginBottom: 12,
  },
  downloadButtons: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  downloadButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    borderRadius: 8,
    flex: 1,
    marginHorizontal: 4,
  },
  downloadButtonText: {
    fontSize: 12,
    fontWeight: '600',
    color: '#ffffff',
    marginLeft: 8,
  },
  detailsContainer: {
    backgroundColor: '#1e293b',
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
  },
  detailsTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#ffffff',
    marginBottom: 12,
  },
  detailItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 6,
  },
  detailLabel: {
    fontSize: 12,
    color: '#94a3b8',
  },
  detailValue: {
    fontSize: 12,
    color: '#ffffff',
    fontWeight: '500',
  },
});