// Powered by OnSpace.AI
import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons, Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';

const { width } = Dimensions.get('window');

const menuItems = [
  { id: 'dashboard', title: 'Live Dashboard', icon: 'dashboard', route: '/dashboard' },
  { id: 'asset-overview', title: 'Asset Overview', icon: 'visibility', route: '/asset-overview' },
  { id: 'analytics', title: 'Asset Analytics', icon: 'analytics', route: '/analytics' },
  { id: 'reports', title: 'History Reports', icon: 'assessment', route: '/reports' },
  { id: 'consumption-reports', title: 'Consumption Reports', icon: 'bar-chart', route: '/consumption-reports' },
  { id: 'energy-trends', title: 'Energy Trends', icon: 'trending-up', route: '/energy-trends' },
  { id: 'device-management', title: 'Device Management', icon: 'devices', route: '/device-management' },
  { id: 'profile', title: 'Profile Information', icon: 'person', route: '/profile' }
];

export default function HomePage() {
  const handleNavigation = (route: string) => {
    router.push(route);
  };

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient
        colors={['#0f172a', '#1e293b', '#334155']}
        style={styles.gradient}
      >
        <ScrollView contentContainerStyle={styles.scrollContent}>
          <View style={styles.header}>
            <Text style={styles.title}>EnergyScope Analytics</Text>
            <Text style={styles.subtitle}>Advanced Energy Monitoring Platform</Text>
          </View>

          <View style={styles.menuGrid}>
            {menuItems.map((item) => (
              <TouchableOpacity
                key={item.id}
                style={styles.menuCard}
                onPress={() => handleNavigation(item.route)}
                activeOpacity={0.8}
              >
                <LinearGradient
                  colors={['#1e40af', '#3b82f6', '#60a5fa']}
                  style={styles.menuGradient}
                >
                  <MaterialIcons name={item.icon as any} size={28} color="#ffffff" />
                  <Text style={styles.menuTitle}>{item.title}</Text>
                </LinearGradient>
              </TouchableOpacity>
            ))}
          </View>

          <View style={styles.footer}>
            <Text style={styles.footerText}>© 2025 All rights reserved.</Text>
            <Text style={styles.footerText}>Made with Mettsenia</Text>
          </View>
        </ScrollView>
      </LinearGradient>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  gradient: {
    flex: 1,
  },
  scrollContent: {
    flexGrow: 1,
    padding: 20,
  },
  header: {
    alignItems: 'center',
    marginBottom: 40,
    paddingTop: 20,
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    color: '#ffffff',
    marginBottom: 8,
  },
  subtitle: {
    fontSize: 16,
    color: '#94a3b8',
    textAlign: 'center',
  },
  menuGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 40,
  },
  menuCard: {
    width: (width - 60) / 2,
    height: 110,
    marginBottom: 16,
    borderRadius: 16,
    overflow: 'hidden',
    elevation: 5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3.84,
  },
  menuGradient: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    padding: 16,
  },
  menuTitle: {
    fontSize: 12,
    fontWeight: '600',
    color: '#ffffff',
    textAlign: 'center',
    marginTop: 8,
    lineHeight: 16,
  },
  footer: {
    alignItems: 'center',
    marginTop: 'auto',
    paddingTop: 20,
  },
  footerText: {
    fontSize: 12,
    color: '#64748b',
    marginBottom: 4,
  },
});