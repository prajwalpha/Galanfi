// Powered by OnSpace.AI
import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons, Ionicons } from '@expo/vector-icons';
import { LineChart, BarChart, PieChart } from 'react-native-chart-kit';
import { router } from 'expo-router';
import { getEnergyTrends } from '../services/energyTrendsService';
import { EnergyTrendsData } from '../services/types';

const { width } = Dimensions.get('window');

const trendPeriods = [
  { id: 'today', label: 'Today', icon: 'today' },
  { id: 'week', label: 'This Week', icon: 'date-range' },
  { id: 'month', label: 'This Month', icon: 'calendar-view-month' },
  { id: 'year', label: 'This Year', icon: 'calendar-today' },
];

export default function EnergyTrends() {
  const [selectedPeriod, setSelectedPeriod] = useState('today');
  const [trendsData, setTrendsData] = useState<EnergyTrendsData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchTrendsData();
  }, [selectedPeriod]);

  const fetchTrendsData = async () => {
    setLoading(true);
    try {
      const data = await getEnergyTrends(selectedPeriod);
      setTrendsData(data);
    } catch (error) {
      console.error('Failed to fetch energy trends:', error);
    } finally {
      setLoading(false);
    }
  };

  const chartConfig = {
    backgroundGradientFrom: '#1e3a8a',
    backgroundGradientTo: '#3b82f6',
    color: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`,
    strokeWidth: 2,
    barPercentage: 0.7,
    useShadowColorFromDataset: false,
  };

  const pieChartData = trendsData ? [
    {
      name: 'Electricity',
      population: trendsData.consumptionBySource.electricity,
      color: '#22c55e',
      legendFontColor: '#94a3b8',
      legendFontSize: 12,
    },
    {
      name: 'Gas',
      population: trendsData.consumptionBySource.gas,
      color: '#f59e0b',
      legendFontColor: '#94a3b8',
      legendFontSize: 12,
    },
    {
      name: 'Water',
      population: trendsData.consumptionBySource.water,
      color: '#3b82f6',
      legendFontColor: '#94a3b8',
      legendFontSize: 12,
    },
  ] : [];

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient colors={['#0f172a', '#1e293b']} style={styles.gradient}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <Ionicons name="arrow-back" size={24} color="#ffffff" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Energy Trends</Text>
          <TouchableOpacity style={styles.settingsButton}>
            <MaterialIcons name="settings" size={24} color="#ffffff" />
          </TouchableOpacity>
        </View>

        <View style={styles.periodContainer}>
          {trendPeriods.map((period) => (
            <TouchableOpacity
              key={period.id}
              style={[
                styles.periodButton,
                selectedPeriod === period.id && styles.periodButtonActive,
              ]}
              onPress={() => setSelectedPeriod(period.id)}
            >
              <MaterialIcons
                name={period.icon as any}
                size={16}
                color={selectedPeriod === period.id ? '#ffffff' : '#94a3b8'}
              />
              <Text
                style={[
                  styles.periodText,
                  selectedPeriod === period.id && styles.periodTextActive,
                ]}
              >
                {period.label}
              </Text>
            </TouchableOpacity>
          ))}
        </View>

        <ScrollView contentContainerStyle={styles.scrollContent}>
          {loading ? (
            <View style={styles.loadingContainer}>
              <Text style={styles.loadingText}>Loading energy trends...</Text>
            </View>
          ) : (
            trendsData && (
              <>
                <View style={styles.metricsContainer}>
                  <View style={styles.metricCard}>
                    <MaterialIcons name="trending-up" size={24} color="#22c55e" />
                    <Text style={styles.metricValue}>{trendsData.totalConsumption.toFixed(2)}</Text>
                    <Text style={styles.metricLabel}>Total kWh</Text>
                    <Text style={styles.metricChange}>
                      {trendsData.consumptionChange > 0 ? '+' : ''}
                      {trendsData.consumptionChange.toFixed(1)}%
                    </Text>
                  </View>
                  <View style={styles.metricCard}>
                    <MaterialIcons name="account-balance-wallet" size={24} color="#3b82f6" />
                    <Text style={styles.metricValue}>₹{trendsData.totalCost.toFixed(2)}</Text>
                    <Text style={styles.metricLabel}>Total Cost</Text>
                    <Text style={styles.metricChange}>
                      {trendsData.costChange > 0 ? '+' : ''}
                      {trendsData.costChange.toFixed(1)}%
                    </Text>
                  </View>
                  <View style={styles.metricCard}>
                    <MaterialIcons name="bolt" size={24} color="#f59e0b" />
                    <Text style={styles.metricValue}>{trendsData.efficiency.toFixed(1)}%</Text>
                    <Text style={styles.metricLabel}>Efficiency</Text>
                    <Text style={styles.metricChange}>
                      {trendsData.efficiencyChange > 0 ? '+' : ''}
                      {trendsData.efficiencyChange.toFixed(1)}%
                    </Text>
                  </View>
                </View>

                <View style={styles.chartContainer}>
                  <Text style={styles.chartTitle}>Consumption Trends</Text>
                  <LineChart
                    data={{
                      labels: trendsData.hourlyData.labels,
                      datasets: [
                        {
                          data: trendsData.hourlyData.consumption,
                          color: (opacity = 1) => `rgba(34, 197, 94, ${opacity})`,
                          strokeWidth: 2,
                        },
                      ],
                    }}
                    width={width - 40}
                    height={220}
                    chartConfig={chartConfig}
                    style={styles.chart}
                    bezier
                  />
                </View>

                <View style={styles.chartContainer}>
                  <Text style={styles.chartTitle}>Energy Sources Distribution</Text>
                  <PieChart
                    data={pieChartData}
                    width={width - 40}
                    height={220}
                    chartConfig={chartConfig}
                    accessor="population"
                    backgroundColor="transparent"
                    paddingLeft="15"
                    absolute
                  />
                </View>

                <View style={styles.chartContainer}>
                  <Text style={styles.chartTitle}>Peak Hours Analysis</Text>
                  <BarChart
                    data={{
                      labels: trendsData.peakHours.labels,
                      datasets: [
                        {
                          data: trendsData.peakHours.values,
                          color: (opacity = 1) => `rgba(239, 68, 68, ${opacity})`,
                          strokeWidth: 2,
                        },
                      ],
                    }}
                    width={width - 40}
                    height={220}
                    chartConfig={chartConfig}
                    style={styles.chart}
                  />
                </View>

                <View style={styles.insightsContainer}>
                  <Text style={styles.insightsTitle}>Key Insights</Text>
                  {trendsData.insights.map((insight, index) => (
                    <View key={index} style={styles.insightItem}>
                      <MaterialIcons name="lightbulb" size={16} color="#f59e0b" />
                      <Text style={styles.insightText}>{insight}</Text>
                    </View>
                  ))}
                </View>
              </>
            )
          )}
        </ScrollView>
      </LinearGradient>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  gradient: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#334155',
  },
  backButton: {
    padding: 8,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  settingsButton: {
    padding: 8,
  },
  periodContainer: {
    flexDirection: 'row',
    paddingHorizontal: 20,
    paddingVertical: 10,
    justifyContent: 'space-between',
  },
  periodButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 8,
    backgroundColor: '#1e293b',
    borderRadius: 20,
    flex: 1,
    marginHorizontal: 4,
    justifyContent: 'center',
  },
  periodButtonActive: {
    backgroundColor: '#3b82f6',
  },
  periodText: {
    fontSize: 10,
    color: '#94a3b8',
    marginLeft: 4,
  },
  periodTextActive: {
    color: '#ffffff',
  },
  scrollContent: {
    padding: 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 60,
  },
  loadingText: {
    fontSize: 16,
    color: '#94a3b8',
  },
  metricsContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  metricCard: {
    backgroundColor: '#1e293b',
    borderRadius: 12,
    padding: 16,
    width: (width - 60) / 3,
    alignItems: 'center',
  },
  metricValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ffffff',
    marginTop: 8,
    marginBottom: 4,
  },
  metricLabel: {
    fontSize: 10,
    color: '#94a3b8',
    marginBottom: 4,
  },
  metricChange: {
    fontSize: 8,
    color: '#22c55e',
  },
  chartContainer: {
    backgroundColor: '#1e293b',
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
  },
  chartTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#ffffff',
    marginBottom: 16,
    textAlign: 'center',
  },
  chart: {
    borderRadius: 8,
  },
  insightsContainer: {
    backgroundColor: '#1e293b',
    borderRadius: 12,
    padding: 16,
  },
  insightsTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#ffffff',
    marginBottom: 16,
  },
  insightItem: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  insightText: {
    fontSize: 12,
    color: '#94a3b8',
    marginLeft: 12,
    flex: 1,
    lineHeight: 16,
  },
});