// Powered by OnSpace.AI
import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Dimensions, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons, Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { getDashboardData } from '../services/dashboardService';

const { width } = Dimensions.get('window');

interface MetricCardProps {
  title: string;
  value: string;
  color: string;
  icon?: string;
}

const MetricCard: React.FC<MetricCardProps> = ({ title, value, color, icon }) => (
  <View style={[styles.metricCard, { backgroundColor: color }]}>
    <View style={styles.metricContent}>
      {icon && <MaterialIcons name={icon as any} size={20} color="#ffffff" />}
      <Text style={styles.metricTitle}>{title}</Text>
      <Text style={styles.metricValue}>{value}</Text>
    </View>
  </View>
);

interface StatusRowProps {
  label: string;
  value: string | number;
  unit?: string;
}

const StatusRow: React.FC<StatusRowProps> = ({ label, value, unit }) => (
  <View style={styles.statusRow}>
    <Text style={styles.statusLabel}>{label}</Text>
    <Text style={styles.statusValue}>
      {value} {unit && <Text style={styles.statusUnit}>{unit}</Text>}
    </Text>
  </View>
);

interface FrequencyRowProps {
  label: string;
  freq: number;
  domRate: number;
}

const FrequencyRow: React.FC<FrequencyRowProps> = ({ label, freq, domRate }) => (
  <View style={styles.frequencyRow}>
    <Text style={styles.frequencyLabel}>{label}</Text>
    <Text style={styles.frequencyValue}>{freq.toFixed(2)}</Text>
    <Text style={styles.frequencyDomRate}>{domRate}</Text>
  </View>
);

interface DataTableRowProps {
  blockTime: string;
  blockNo: number;
  se: number;
  ae: number;
  kwhSch: number;
  kwhExp: number;
  uiUnits: number;
  hz: number;
  uiRate: number;
  uiAmt: number;
  isHighlighted?: boolean;
}

const DataTableRow: React.FC<DataTableRowProps> = ({
  blockTime,
  blockNo,
  se,
  ae,
  kwhSch,
  kwhExp,
  uiUnits,
  hz,
  uiRate,
  uiAmt,
  isHighlighted = false
}) => (
  <View style={[styles.dataRow, isHighlighted && styles.dataRowHighlighted]}>
    <Text style={styles.dataCell}>{blockTime}</Text>
    <Text style={styles.dataCell}>{blockNo}</Text>
    <Text style={styles.dataCell}>{se.toFixed(2)}</Text>
    <Text style={styles.dataCell}>{ae.toFixed(2)}</Text>
    <Text style={styles.dataCell}>{kwhSch.toFixed(2)}</Text>
    <Text style={styles.dataCell}>{kwhExp.toFixed(2)}</Text>
    <Text style={styles.dataCell}>{uiUnits.toFixed(2)}</Text>
    <Text style={styles.dataCell}>{hz.toFixed(2)}</Text>
    <Text style={styles.dataCell}>{uiRate.toFixed(2)}</Text>
    <Text style={styles.dataCell}>{uiAmt.toFixed(2)}</Text>
  </View>
);

export default function Dashboard() {
  const [dashboardData, setDashboardData] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await getDashboardData();
        setDashboardData(data);
      } catch (error) {
        console.error('Failed to fetch dashboard data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit', 
      second: '2-digit',
      hour12: true 
    });
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <View style={styles.loadingContainer}>
          <Text style={styles.loadingText}>Loading Dashboard...</Text>
        </View>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <View style={styles.header}>
        <TouchableOpacity onPress={() => router.back()} style={styles.menuButton}>
          <MaterialIcons name="menu" size={24} color="#64748b" />
        </TouchableOpacity>
        <Text style={styles.headerTitle}>Dashboard</Text>
        <Image 
          source={{ uri: 'https://picsum.photos/seed/company-logo/80/40.webp' }}
          style={styles.logo}
          accessibilityLabel="Company logo displaying the organization branding"
        />
        <View style={styles.headerRight}>
          <TouchableOpacity style={styles.meterButton}>
            <Text style={styles.meterButtonText}>[T] - LINE 2 METER</Text>
          </TouchableOpacity>
          <TouchableOpacity style={styles.calendarButton}>
            <MaterialIcons name="calendar-today" size={20} color="#ffffff" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.profileButton}>
            <MaterialIcons name="person" size={20} color="#ffffff" />
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView style={styles.scrollContainer}>
        {/* Top Metrics Cards */}
        <View style={styles.metricsRow}>
          <MetricCard
            title="Current Time"
            value={formatTime(currentTime)}
            color="#22c55e"
            icon="access-time"
          />
          <MetricCard
            title="Station Schedule(kW)"
            value="0"
            color="#f59e0b"
            icon="schedule"
          />
          <MetricCard
            title="Station EX-BUS(kW)"
            value="-0.15"
            color="#8b5cf6"
            icon="electrical-services"
          />
          <MetricCard
            title="Station Avg.EX-BUS(kW)"
            value="-0.15"
            color="#94a3b8"
            icon="trending-up"
          />
          <MetricCard
            title="Avg.Frequency(Hz)"
            value="49.89"
            color="#06b6d4"
            icon="waves"
          />
          <MetricCard
            title="Avg.DSM Rate(Rs.)"
            value="0"
            color="#ec4899"
            icon="currency-rupee"
          />
        </View>

        <View style={styles.contentRow}>
          {/* Left Column */}
          <View style={styles.leftColumn}>
            {/* Status Information */}
            <View style={styles.statusCard}>
              <StatusRow label="Block NO." value="66" />
              <StatusRow label="Block Time Range" value="16:15 - 16:30" />
              <StatusRow label="Time Elapsed" value="10:22" />
              <StatusRow label="Time Remaining" value="4:38" />
              <StatusRow label="Real Time APC(kW)" value="0.00" />
              <StatusRow label="Real Time APC(%)" value="0.00" />
              <StatusRow label="Current SG Status" value="0.00" />
              <StatusRow label="Avg SG Status" value="0.00%" />
            </View>

            {/* Frequency Trend Table */}
            <View style={styles.frequencyCard}>
              <View style={styles.frequencyHeader}>
                <Text style={styles.frequencyHeaderText}>Frequency Trend</Text>
                <Text style={styles.frequencyHeaderText}>Freq</Text>
                <Text style={styles.frequencyHeaderText}>Dom Rate</Text>
              </View>
              <FrequencyRow label="Avg Freq of Block" freq={49.89} domRate={0} />
              <FrequencyRow label="Current Freq" freq={49.89} domRate={0} />
              <FrequencyRow label="Last 4 Min Avg" freq={49.89} domRate={0} />
              <FrequencyRow label="Forecast Freq" freq={49.89} domRate={0} />
              <FrequencyRow label="Break Even Hz" freq={49.89} domRate={0} />
            </View>
          </View>

          {/* Right Column */}
          <View style={styles.rightColumn}>
            {/* Meter Status */}
            <View style={styles.meterCard}>
              <View style={styles.meterHeader}>
                <Text style={styles.meterName}>MeterName</Text>
                <Text style={styles.meterType}>ABT</Text>
              </View>
              <View style={styles.meterStatus}>
                <Text style={styles.meterStatusLabel}>Last Status</Text>
                <Text style={styles.meterStatusValue}>1 Min</Text>
              </View>
              <View style={styles.meterLoad}>
                <Text style={styles.meterLoadLabel}>Current Load</Text>
                <Text style={styles.meterLoadValue}>-0.15</Text>
              </View>
              <View style={styles.suggestions}>
                <Text style={styles.suggestionsLabel}>Suggestions</Text>
                <Text style={styles.suggestionsText}>
                  <Text style={styles.maintainText}>Maintain Load </Text>
                  <Text style={styles.redText}>0.15 </Text>
                  <Text style={styles.maintainText}>To Meet </Text>
                  <Text style={styles.greenText}>100% </Text>
                  <Text style={styles.maintainText}>of Schedule </Text>
                  <Text style={styles.redText}>(0 kW )</Text>
                  <Text style={styles.maintainText}>And Your Present Injection is </Text>
                  <Text style={styles.redText}>Infinity%</Text>
                </Text>
              </View>
            </View>

            {/* Target Schedule Table */}
            <View style={styles.targetCard}>
              <View style={styles.targetHeader}>
                <Text style={styles.targetHeaderCell}>Target Schedule R6</Text>
                <Text style={styles.targetHeaderCell}>100%</Text>
                <Text style={styles.targetHeaderCell}>12%</Text>
                <Text style={styles.targetHeaderCell}>88%</Text>
                <Text style={styles.targetHeaderCell}>Estimated Energy(kWh)</Text>
                <Text style={styles.targetHeaderCell}>Energy Generated(kWh)</Text>
                <Text style={styles.targetHeaderCell}>Over Injection</Text>
                <Text style={styles.targetHeaderCell}>Under Injection</Text>
                <Text style={styles.targetHeaderCell}>Penalty</Text>
                <Text style={styles.targetHeaderCell}>Receive</Text>
                <Text style={styles.targetHeaderCell}>Net UI</Text>
              </View>
              <View style={styles.targetRow}>
                <Text style={styles.targetCell}>ABT</Text>
                <Text style={styles.targetCell}>-0.15</Text>
                <Text style={styles.targetCell}>-0.01</Text>
                <Text style={styles.targetCell}>-0.00</Text>
                <Text style={styles.targetCell}>0.00</Text>
                <Text style={styles.targetCell}>0.00</Text>
                <Text style={styles.targetCell}>0.00</Text>
                <Text style={styles.targetCell}>0.00</Text>
                <Text style={styles.targetCell}>0.00</Text>
                <Text style={styles.targetCell}>0.00</Text>
                <Text style={styles.targetCell}>--</Text>
              </View>
          </View>
        </View>
        </View>

        {/* Data Table */}
        <View style={styles.dataTable}>
          <View style={styles.dataTableHeader}>
            <Text style={styles.dataHeaderCell}>Block Time</Text>
            <Text style={styles.dataHeaderCell}>Block No</Text>
            <Text style={styles.dataHeaderCell}>SE(kW)</Text>
            <Text style={styles.dataHeaderCell}>AE(kW)</Text>
            <Text style={styles.dataHeaderCell}>kWh(Sch)</Text>
            <Text style={styles.dataHeaderCell}>kWh(Exp)</Text>
            <Text style={styles.dataHeaderCell}>UI Units</Text>
            <Text style={styles.dataHeaderCell}>Hz</Text>
            <Text style={styles.dataHeaderCell}>UI Rate</Text>
            <Text style={styles.dataHeaderCell}>UI Amt.</Text>
          </View>
          
          <DataTableRow
            blockTime="10-07-2025 16:15:00"
            blockNo={66}
            se={0.00}
            ae={0.24}
            kwhSch={0.00}
            kwhExp={0.00}
            uiUnits={0.00}
            hz={49.93}
            uiRate={0.00}
            uiAmt={0.00}
            isHighlighted={true}
          />
          <DataTableRow
            blockTime="10-07-2025 16:00:00"
            blockNo={65}
            se={0.00}
            ae={0.22}
            kwhSch={0.00}
            kwhExp={0.00}
            uiUnits={0.00}
            hz={50.05}
            uiRate={0.00}
            uiAmt={0.00}
          />
          <DataTableRow
            blockTime="10-07-2025 15:45:00"
            blockNo={64}
            se={0.00}
            ae={0.22}
            kwhSch={0.00}
            kwhExp={0.00}
            uiUnits={0.00}
            hz={50.03}
            uiRate={0.00}
            uiAmt={0.00}
            isHighlighted={true}
          />
          <DataTableRow
            blockTime="10-07-2025 15:30:00"
            blockNo={63}
            se={0.00}
            ae={0.35}
            kwhSch={0.00}
            kwhExp={0.00}
            uiUnits={0.00}
            hz={49.98}
            uiRate={0.00}
            uiAmt={0.00}
          />
          <DataTableRow
            blockTime="10-07-2025 15:15:00"
            blockNo={62}
            se={0.00}
            ae={0.22}
            kwhSch={0.00}
            kwhExp={0.00}
            uiUnits={0.00}
            hz={50.01}
            uiRate={0.00}
            uiAmt={0.00}
            isHighlighted={true}
          />
          <DataTableRow
            blockTime="10-07-2025 15:00:00"
            blockNo={61}
            se={0.00}
            ae={0.71}
            kwhSch={0.00}
            kwhExp={0.00}
            uiUnits={0.00}
            hz={50.06}
            uiRate={0.00}
            uiAmt={0.00}
          />
          <DataTableRow
            blockTime="10-07-2025 14:45:00"
            blockNo={60}
            se={0.00}
            ae={0.43}
            kwhSch={0.00}
            kwhExp={0.00}
            uiUnits={0.00}
            hz={50.04}
            uiRate={0.00}
            uiAmt={0.00}
            isHighlighted={true}
          />
          <DataTableRow
            blockTime="10-07-2025 14:30:00"
            blockNo={59}
            se={0.00}
            ae={0.46}
            kwhSch={0.00}
            kwhExp={0.00}
            uiUnits={0.00}
            hz={50.13}
            uiRate={0.00}
            uiAmt={0.00}
          />
          <DataTableRow
            blockTime="10-07-2025 14:15:00"
            blockNo={58}
            se={0.00}
            ae={0.44}
            kwhSch={0.00}
            kwhExp={0.00}
            uiUnits={0.00}
            hz={50.04}
            uiRate={0.00}
            uiAmt={0.00}
            isHighlighted={true}
          />
          <DataTableRow
            blockTime="10-07-2025 14:00:00"
            blockNo={57}
            se={0.00}
            ae={0.46}
            kwhSch={0.00}
            kwhExp={0.00}
            uiUnits={0.00}
            hz={50.13}
            uiRate={0.00}
            uiAmt={0.00}
          />
          <DataTableRow
            blockTime="10-07-2025 13:45:00"
            blockNo={56}
            se={0.00}
            ae={0.36}
            kwhSch={0.00}
            kwhExp={0.00}
            uiUnits={0.00}
            hz={50.11}
            uiRate={0.00}
            uiAmt={0.00}
            isHighlighted={true}
          />
          <DataTableRow
            blockTime="10-07-2025 13:30:00"
            blockNo={55}
            se={0.00}
            ae={0.21}
            kwhSch={0.00}
            kwhExp={0.00}
            uiUnits={0.00}
            hz={50.12}
            uiRate={0.00}
            uiAmt={0.00}
          />
          <DataTableRow
            blockTime="10-07-2025 13:15:00"
            blockNo={54}
            se={0.00}
            ae={0.39}
            kwhSch={0.00}
            kwhExp={0.00}
            uiUnits={0.00}
            hz={50.26}
            uiRate={0.00}
            uiAmt={0.00}
            isHighlighted={true}
          />
          <DataTableRow
            blockTime="10-07-2025 13:00:00"
            blockNo={53}
            se={0.00}
            ae={0.41}
            kwhSch={0.00}
            kwhExp={0.00}
            uiUnits={0.00}
            hz={50.30}
            uiRate={0.00}
            uiAmt={0.00}
          />
        </View>
      </ScrollView>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#f8fafc',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    fontSize: 16,
    color: '#64748b',
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: '#ffffff',
    borderBottomWidth: 1,
    borderBottomColor: '#e2e8f0',
  },
  menuButton: {
    padding: 8,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: '600',
    color: '#1e293b',
  },
  logo: {
    width: 80,
    height: 40,
    resizeMode: 'contain',
  },
  headerRight: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  meterButton: {
    backgroundColor: '#8b5cf6',
    paddingHorizontal: 16,
    paddingVertical: 8,
    borderRadius: 20,
    marginRight: 8,
  },
  meterButtonText: {
    color: '#ffffff',
    fontSize: 12,
    fontWeight: '600',
  },
  calendarButton: {
    backgroundColor: '#22c55e',
    padding: 8,
    borderRadius: 20,
    marginRight: 8,
  },
  profileButton: {
    backgroundColor: '#64748b',
    padding: 8,
    borderRadius: 20,
  },
  scrollContainer: {
    flex: 1,
    padding: 16,
  },
  metricsRow: {
    flexDirection: 'row',
    marginBottom: 16,
    gap: 8,
  },
  metricCard: {
    flex: 1,
    borderRadius: 8,
    padding: 12,
    minHeight: 80,
  },
  metricContent: {
    alignItems: 'center',
  },
  metricTitle: {
    fontSize: 10,
    color: '#ffffff',
    textAlign: 'center',
    marginBottom: 4,
    fontWeight: '500',
  },
  metricValue: {
    fontSize: 16,
    color: '#ffffff',
    fontWeight: 'bold',
    textAlign: 'center',
  },
  contentRow: {
    flexDirection: 'row',
    marginBottom: 16,
    gap: 16,
  },
  leftColumn: {
    flex: 1,
  },
  rightColumn: {
    flex: 1,
  },
  statusCard: {
    backgroundColor: '#ffffff',
    borderRadius: 8,
    padding: 16,
    marginBottom: 16,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  statusRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    paddingVertical: 6,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  statusLabel: {
    fontSize: 12,
    color: '#64748b',
    flex: 1,
  },
  statusValue: {
    fontSize: 12,
    color: '#1e293b',
    fontWeight: '600',
    textAlign: 'right',
  },
  statusUnit: {
    fontSize: 10,
    color: '#94a3b8',
  },
  frequencyCard: {
    backgroundColor: '#22c55e',
    borderRadius: 8,
    padding: 16,
  },
  frequencyHeader: {
    flexDirection: 'row',
    paddingBottom: 8,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.3)',
    marginBottom: 8,
  },
  frequencyHeaderText: {
    flex: 1,
    fontSize: 12,
    color: '#ffffff',
    fontWeight: '600',
    textAlign: 'center',
  },
  frequencyRow: {
    flexDirection: 'row',
    paddingVertical: 4,
  },
  frequencyLabel: {
    flex: 1,
    fontSize: 11,
    color: '#ffffff',
  },
  frequencyValue: {
    flex: 1,
    fontSize: 11,
    color: '#ffffff',
    textAlign: 'center',
    fontWeight: '500',
  },
  frequencyDomRate: {
    flex: 1,
    fontSize: 11,
    color: '#ffffff',
    textAlign: 'center',
    fontWeight: '500',
  },
  meterCard: {
    backgroundColor: '#ef4444',
    borderRadius: 8,
    padding: 16,
    marginBottom: 16,
  },
  meterHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  meterName: {
    fontSize: 14,
    color: '#ffffff',
    fontWeight: '600',
  },
  meterType: {
    fontSize: 14,
    color: '#ffffff',
    fontWeight: '600',
  },
  meterStatus: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 8,
  },
  meterStatusLabel: {
    fontSize: 12,
    color: '#ffffff',
  },
  meterStatusValue: {
    fontSize: 12,
    color: '#ffffff',
    fontWeight: '500',
  },
  meterLoad: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  meterLoadLabel: {
    fontSize: 12,
    color: '#ffffff',
  },
  meterLoadValue: {
    fontSize: 12,
    color: '#ffffff',
    fontWeight: '500',
  },
  suggestions: {
    marginTop: 8,
  },
  suggestionsLabel: {
    fontSize: 12,
    color: '#ffffff',
    fontWeight: '600',
    marginBottom: 4,
  },
  suggestionsText: {
    fontSize: 10,
    lineHeight: 14,
  },
  maintainText: {
    color: '#ffffff',
  },
  redText: {
    color: '#fecaca',
    fontWeight: '600',
  },
  greenText: {
    color: '#bbf7d0',
    fontWeight: '600',
  },
  targetCard: {
    backgroundColor: '#06b6d4',
    borderRadius: 8,
    padding: 12,
  },
  targetHeader: {
    flexDirection: 'row',
    paddingBottom: 8,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.3)',
    marginBottom: 8,
  },
  targetHeaderCell: {
    flex: 1,
    fontSize: 8,
    color: '#ffffff',
    fontWeight: '600',
    textAlign: 'center',
  },
  targetRow: {
    flexDirection: 'row',
  },
  targetCell: {
    flex: 1,
    fontSize: 10,
    color: '#ffffff',
    textAlign: 'center',
    fontWeight: '500',
  },
  dataTable: {
    backgroundColor: '#ffffff',
    borderRadius: 8,
    borderWidth: 1,
    borderColor: '#e2e8f0',
  },
  dataTableHeader: {
    flexDirection: 'row',
    backgroundColor: '#06b6d4',
    paddingVertical: 12,
    paddingHorizontal: 8,
    borderTopLeftRadius: 8,
    borderTopRightRadius: 8,
  },
  dataHeaderCell: {
    flex: 1,
    fontSize: 10,
    color: '#ffffff',
    fontWeight: '600',
    textAlign: 'center',
  },
  dataRow: {
    flexDirection: 'row',
    paddingVertical: 8,
    paddingHorizontal: 8,
    borderBottomWidth: 1,
    borderBottomColor: '#f1f5f9',
  },
  dataRowHighlighted: {
    backgroundColor: '#fef3c7',
  },
  dataCell: {
    flex: 1,
    fontSize: 9,
    color: '#1e293b',
    textAlign: 'center',
  },
});