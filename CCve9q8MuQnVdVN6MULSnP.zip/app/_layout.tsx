// Powered by OnSpace.AI
import { Stack } from 'expo-router';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { PaperProvider } from 'react-native-paper';

export default function RootLayout() {
  return (
    <SafeAreaProvider>
      <PaperProvider>
        <Stack screenOptions={{ headerShown: false }}>
          <Stack.Screen name="index" />
          <Stack.Screen name="dashboard" />
          <Stack.Screen name="asset-overview" />
          <Stack.Screen name="analytics" />
          <Stack.Screen name="reports" />
          <Stack.Screen name="consumption-reports" />
          <Stack.Screen name="energy-trends" />
          <Stack.Screen name="device-management" />
          <Stack.Screen name="profile" />
        </Stack>
      </PaperProvider>
    </SafeAreaProvider>
  );
}