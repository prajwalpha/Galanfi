// Powered by OnSpace.AI
import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Image, Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons, Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { getUserProfile } from '../services/userService';

const { width } = Dimensions.get('window');

interface ProfileSectionProps {
  title: string;
  icon: string;
  value: string;
  editable?: boolean;
  onPress?: () => void;
}

const ProfileSection: React.FC<ProfileSectionProps> = ({ title, icon, value, editable = false, onPress }) => (
  <TouchableOpacity
    style={styles.profileSection}
    onPress={onPress}
    disabled={!editable}
    activeOpacity={editable ? 0.7 : 1}
  >
    <View style={styles.sectionLeft}>
      <MaterialIcons name={icon as any} size={24} color="#3b82f6" />
      <View style={styles.sectionInfo}>
        <Text style={styles.sectionTitle}>{title}</Text>
        <Text style={styles.sectionValue}>{value}</Text>
      </View>
    </View>
    {editable && (
      <MaterialIcons name="chevron-right" size={24} color="#94a3b8" />
    )}
  </TouchableOpacity>
);

export default function Profile() {
  const [userProfile, setUserProfile] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const profile = await getUserProfile();
        setUserProfile(profile);
      } catch (error) {
        console.error('Failed to fetch user profile:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchProfile();
  }, []);

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={['#0f172a', '#1e293b']} style={styles.gradient}>
          <View style={styles.loadingContainer}>
            <Text style={styles.loadingText}>Loading Profile...</Text>
          </View>
        </LinearGradient>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient colors={['#0f172a', '#1e293b']} style={styles.gradient}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <Ionicons name="arrow-back" size={24} color="#ffffff" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Profile Information</Text>
          <TouchableOpacity style={styles.editButton}>
            <MaterialIcons name="edit" size={20} color="#ffffff" />
          </TouchableOpacity>
        </View>

        <ScrollView contentContainerStyle={styles.scrollContent}>
          <View style={styles.profileHeader}>
            <View style={styles.avatarContainer}>
              <Image
                source={{ uri: 'https://picsum.photos/seed/user-avatar/120/120.webp' }}
                style={styles.avatar}
                accessibilityLabel="User profile avatar showing a professional headshot"
              />
              <TouchableOpacity style={styles.avatarEdit}>
                <MaterialIcons name="camera-alt" size={16} color="#ffffff" />
              </TouchableOpacity>
            </View>
            <Text style={styles.userName}>{userProfile?.name || 'John Doe'}</Text>
            <Text style={styles.userEmail}>{userProfile?.email || 'john.doe@company.com'}</Text>
            <Text style={styles.userRole}>{userProfile?.role || 'Energy Manager'}</Text>
          </View>

          <View style={styles.profileContent}>
            <Text style={styles.sectionHeader}>Personal Information</Text>
            <View style={styles.sectionContainer}>
              <ProfileSection
                title="Full Name"
                icon="person"
                value={userProfile?.name || 'John Doe'}
                editable={true}
              />
              <ProfileSection
                title="Email Address"
                icon="email"
                value={userProfile?.email || 'john.doe@company.com'}
                editable={true}
              />
              <ProfileSection
                title="Phone Number"
                icon="phone"
                value={userProfile?.phone || '+1 (555) 123-4567'}
                editable={true}
              />
              <ProfileSection
                title="Department"
                icon="business"
                value={userProfile?.department || 'Energy Management'}
                editable={true}
              />
            </View>

            <Text style={styles.sectionHeader}>System Information</Text>
            <View style={styles.sectionContainer}>
              <ProfileSection
                title="User ID"
                icon="badge"
                value={userProfile?.id || 'EM-2025-001'}
              />
              <ProfileSection
                title="Role"
                icon="security"
                value={userProfile?.role || 'Energy Manager'}
              />
              <ProfileSection
                title="Access Level"
                icon="verified-user"
                value={userProfile?.accessLevel || 'Administrator'}
              />
              <ProfileSection
                title="Last Login"
                icon="schedule"
                value={userProfile?.lastLogin || 'Today, 09:30 AM'}
              />
            </View>

            <Text style={styles.sectionHeader}>Preferences</Text>
            <View style={styles.sectionContainer}>
              <ProfileSection
                title="Language"
                icon="language"
                value={userProfile?.language || 'English'}
                editable={true}
              />
              <ProfileSection
                title="Time Zone"
                icon="schedule"
                value={userProfile?.timezone || 'UTC+05:30'}
                editable={true}
              />
              <ProfileSection
                title="Notification Settings"
                icon="notifications"
                value="Email + Push"
                editable={true}
              />
              <ProfileSection
                title="Theme"
                icon="palette"
                value={userProfile?.theme || 'Dark Mode'}
                editable={true}
              />
            </View>

            <View style={styles.actionButtons}>
              <TouchableOpacity style={styles.actionButton}>
                <MaterialIcons name="security" size={20} color="#ffffff" />
                <Text style={styles.actionButtonText}>Change Password</Text>
              </TouchableOpacity>
              <TouchableOpacity style={styles.actionButton}>
                <MaterialIcons name="download" size={20} color="#ffffff" />
                <Text style={styles.actionButtonText}>Export Data</Text>
              </TouchableOpacity>
              <TouchableOpacity style={[styles.actionButton, styles.logoutButton]}>
                <MaterialIcons name="logout" size={20} color="#ffffff" />
                <Text style={styles.actionButtonText}>Logout</Text>
              </TouchableOpacity>
            </View>
          </View>
        </ScrollView>
      </LinearGradient>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  gradient: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#334155',
  },
  backButton: {
    padding: 8,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  editButton: {
    padding: 8,
  },
  scrollContent: {
    flexGrow: 1,
  },
  profileHeader: {
    alignItems: 'center',
    paddingVertical: 30,
    backgroundColor: '#1e293b',
    marginBottom: 20,
  },
  avatarContainer: {
    position: 'relative',
    marginBottom: 16,
  },
  avatar: {
    width: 120,
    height: 120,
    borderRadius: 60,
    borderWidth: 4,
    borderColor: '#3b82f6',
  },
  avatarEdit: {
    position: 'absolute',
    bottom: 0,
    right: 0,
    backgroundColor: '#3b82f6',
    borderRadius: 16,
    width: 32,
    height: 32,
    justifyContent: 'center',
    alignItems: 'center',
    borderWidth: 2,
    borderColor: '#1e293b',
  },
  userName: {
    fontSize: 24,
    fontWeight: 'bold',
    color: '#ffffff',
    marginBottom: 4,
  },
  userEmail: {
    fontSize: 14,
    color: '#94a3b8',
    marginBottom: 2,
  },
  userRole: {
    fontSize: 12,
    color: '#3b82f6',
    backgroundColor: '#1e3a8a',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 12,
  },
  profileContent: {
    paddingHorizontal: 20,
  },
  sectionHeader: {
    fontSize: 16,
    fontWeight: '600',
    color: '#ffffff',
    marginBottom: 16,
    marginTop: 20,
  },
  sectionContainer: {
    backgroundColor: '#1e293b',
    borderRadius: 12,
    marginBottom: 20,
  },
  profileSection: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 16,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#374151',
  },
  sectionLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  sectionInfo: {
    marginLeft: 16,
    flex: 1,
  },
  sectionTitle: {
    fontSize: 12,
    color: '#94a3b8',
    marginBottom: 4,
  },
  sectionValue: {
    fontSize: 14,
    color: '#ffffff',
    fontWeight: '500',
  },
  actionButtons: {
    marginTop: 20,
    marginBottom: 40,
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: '#3b82f6',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderRadius: 12,
    marginBottom: 12,
  },
  logoutButton: {
    backgroundColor: '#dc2626',
  },
  actionButtonText: {
    fontSize: 14,
    fontWeight: '600',
    color: '#ffffff',
    marginLeft: 12,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    fontSize: 16,
    color: '#ffffff',
  },
});