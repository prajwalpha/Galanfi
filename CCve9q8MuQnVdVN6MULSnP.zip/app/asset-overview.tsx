// Powered by OnSpace.AI
import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons, Ionicons } from '@expo/vector-icons';
import { LineChart, BarChart } from 'react-native-chart-kit';
import { router } from 'expo-router';
import { getAssetOverviewData } from '../services/energyService';

const { width } = Dimensions.get('window');

interface MetricCardProps {
  title: string;
  value: string;
  unit: string;
  icon: string;
  color: string;
}

const MetricCard: React.FC<MetricCardProps> = ({ title, value, unit, icon, color }) => (
  <View style={[styles.metricCard, { backgroundColor: color }]}>
    <View style={styles.metricIcon}>
      <MaterialIcons name={icon as any} size={24} color="#ffffff" />
    </View>
    <View style={styles.metricInfo}>
      <Text style={styles.metricTitle}>{title}</Text>
      <Text style={styles.metricValue}>{value}</Text>
      <Text style={styles.metricUnit}>{unit}</Text>
    </View>
  </View>
);

export default function AssetOverview() {
  const [overviewData, setOverviewData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await getAssetOverviewData();
        setOverviewData(data);
      } catch (error) {
        console.error('Failed to fetch asset overview data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const chartConfig = {
    backgroundGradientFrom: '#1e3a8a',
    backgroundGradientTo: '#3b82f6',
    color: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`,
    strokeWidth: 2,
    barPercentage: 0.5,
    useShadowColorFromDataset: false,
  };

  const costConsumptionData = {
    labels: ['Feb-01', 'Feb-02'],
    datasets: [
      {
        data: [320, 50],
        color: (opacity = 1) => `rgba(255, 99, 132, ${opacity})`,
        strokeWidth: 2,
      },
    ],
  };

  const hourlyData = {
    labels: ['11:00', '13:00', '15:00', '17:00', '19:00', '21:00', '23:00'],
    datasets: [
      {
        data: [0, 0, 0, 0, 0, 0, 0],
        color: (opacity = 1) => `rgba(34, 197, 94, ${opacity})`,
        strokeWidth: 2,
      },
    ],
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={['#0f172a', '#1e293b']} style={styles.gradient}>
          <View style={styles.loadingContainer}>
            <Text style={styles.loadingText}>Loading...</Text>
          </View>
        </LinearGradient>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient colors={['#0f172a', '#1e293b']} style={styles.gradient}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <Ionicons name="arrow-back" size={24} color="#ffffff" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Asset Overview</Text>
          <View style={styles.headerRight}>
            <Text style={styles.headerSubtitle}>Electricity</Text>
            <Text style={styles.headerSubtitle}>Meter1</Text>
          </View>
        </View>

        <ScrollView contentContainerStyle={styles.scrollContent}>
          <View style={styles.metricsGrid}>
            <MetricCard
              title="Today Consumption"
              value="0.00"
              unit="kWh Imp"
              icon="flash-on"
              color="#dc2626"
            />
            <MetricCard
              title="WI Imp"
              value="0.00"
              unit=""
              icon="trending-up"
              color="#16a34a"
            />
            <MetricCard
              title="This Month Consumption"
              value="0.00"
              unit="kWh Imp"
              icon="calendar-today"
              color="#7c3aed"
            />
            <MetricCard
              title="This Month Cost"
              value="₹0.00"
              unit=""
              icon="account-balance-wallet"
              color="#0ea5e9"
            />
          </View>

          <View style={styles.additionalMetrics}>
            <View style={styles.metricRow}>
              <Text style={styles.metricLabel}>Yesterday WI Imp:</Text>
              <Text style={styles.metricValue}>51.14 kWh Imp</Text>
            </View>
            <View style={styles.metricRow}>
              <Text style={styles.metricLabel}>Yesterday Cost:</Text>
              <Text style={styles.metricValue}>₹319.63</Text>
            </View>
            <View style={styles.metricRow}>
              <Text style={styles.metricLabel}>Forecast Cost:</Text>
              <Text style={styles.metricValue}>₹320.72</Text>
            </View>
            <View style={styles.metricRow}>
              <Text style={styles.metricLabel}>Last Month Consumption:</Text>
              <Text style={styles.metricValue}>2679.59 kWh Imp</Text>
            </View>
            <View style={styles.metricRow}>
              <Text style={styles.metricLabel}>Last Month Cost:</Text>
              <Text style={styles.metricValue}>₹16747.44</Text>
            </View>
            <View style={styles.metricRow}>
              <Text style={styles.metricLabel}>Lifetime Cost:</Text>
              <Text style={styles.metricValue}>₹8904.63</Text>
            </View>
          </View>

          <View style={styles.chartContainer}>
            <Text style={styles.chartTitle}>Meter1 - Cost v/s Consumption</Text>
            <BarChart
              data={costConsumptionData}
              width={width - 40}
              height={220}
              chartConfig={chartConfig}
              style={styles.chart}
            />
          </View>

          <View style={styles.chartContainer}>
            <Text style={styles.chartTitle}>Meter1 - Hourly Consumption</Text>
            <LineChart
              data={hourlyData}
              width={width - 40}
              height={220}
              chartConfig={chartConfig}
              style={styles.chart}
            />
          </View>
        </ScrollView>
      </LinearGradient>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  gradient: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#334155',
  },
  backButton: {
    padding: 8,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  headerRight: {
    alignItems: 'flex-end',
  },
  headerSubtitle: {
    fontSize: 12,
    color: '#94a3b8',
  },
  scrollContent: {
    padding: 20,
  },
  metricsGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  metricCard: {
    width: (width - 60) / 2,
    padding: 16,
    borderRadius: 12,
    marginBottom: 12,
    flexDirection: 'row',
    alignItems: 'center',
  },
  metricIcon: {
    marginRight: 12,
  },
  metricInfo: {
    flex: 1,
  },
  metricTitle: {
    fontSize: 10,
    color: '#ffffff',
    marginBottom: 4,
  },
  metricValue: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  metricUnit: {
    fontSize: 8,
    color: '#ffffff',
    opacity: 0.8,
  },
  additionalMetrics: {
    backgroundColor: '#1e293b',
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
  },
  metricRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingVertical: 4,
  },
  metricLabel: {
    fontSize: 12,
    color: '#94a3b8',
  },
  chartContainer: {
    backgroundColor: '#1e293b',
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
  },
  chartTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#ffffff',
    marginBottom: 16,
    textAlign: 'center',
  },
  chart: {
    borderRadius: 8,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    fontSize: 16,
    color: '#ffffff',
  },
});