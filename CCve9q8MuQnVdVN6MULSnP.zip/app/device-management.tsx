// Powered by OnSpace.AI
import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Dimensions, Alert } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons, Ionicons } from '@expo/vector-icons';
import { router } from 'expo-router';
import { getDeviceList, updateDeviceSettings } from '../services/deviceService';
import { DeviceInfo } from '../services/types';

const { width } = Dimensions.get('window');

export default function DeviceManagement() {
  const [devices, setDevices] = useState<DeviceInfo[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedDevice, setSelectedDevice] = useState<string | null>(null);

  useEffect(() => {
    fetchDevices();
  }, []);

  const fetchDevices = async () => {
    setLoading(true);
    try {
      const deviceList = await getDeviceList();
      setDevices(deviceList);
    } catch (error) {
      console.error('Failed to fetch devices:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleDeviceToggle = async (deviceId: string, enabled: boolean) => {
    try {
      await updateDeviceSettings(deviceId, { enabled });
      setDevices(devices.map(device => 
        device.id === deviceId ? { ...device, enabled } : device
      ));
      Alert.alert('Success', `Device ${enabled ? 'enabled' : 'disabled'} successfully`);
    } catch (error) {
      Alert.alert('Error', 'Failed to update device settings');
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'online': return '#22c55e';
      case 'offline': return '#ef4444';
      case 'maintenance': return '#f59e0b';
      default: return '#94a3b8';
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'online': return 'check-circle';
      case 'offline': return 'cancel';
      case 'maintenance': return 'build';
      default: return 'help';
    }
  };

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient colors={['#0f172a', '#1e293b']} style={styles.gradient}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <Ionicons name="arrow-back" size={24} color="#ffffff" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Device Management</Text>
          <TouchableOpacity style={styles.addButton}>
            <MaterialIcons name="add" size={24} color="#ffffff" />
          </TouchableOpacity>
        </View>

        <ScrollView contentContainerStyle={styles.scrollContent}>
          {loading ? (
            <View style={styles.loadingContainer}>
              <Text style={styles.loadingText}>Loading devices...</Text>
            </View>
          ) : (
            <>
              <View style={styles.summaryContainer}>
                <View style={styles.summaryCard}>
                  <MaterialIcons name="devices" size={24} color="#3b82f6" />
                  <Text style={styles.summaryValue}>{devices.length}</Text>
                  <Text style={styles.summaryLabel}>Total Devices</Text>
                </View>
                <View style={styles.summaryCard}>
                  <MaterialIcons name="check-circle" size={24} color="#22c55e" />
                  <Text style={styles.summaryValue}>
                    {devices.filter(d => d.status === 'online').length}
                  </Text>
                  <Text style={styles.summaryLabel}>Online</Text>
                </View>
                <View style={styles.summaryCard}>
                  <MaterialIcons name="warning" size={24} color="#f59e0b" />
                  <Text style={styles.summaryValue}>
                    {devices.filter(d => d.status === 'maintenance').length}
                  </Text>
                  <Text style={styles.summaryLabel}>Maintenance</Text>
                </View>
              </View>

              <View style={styles.deviceList}>
                {devices.map((device) => (
                  <TouchableOpacity
                    key={device.id}
                    style={[
                      styles.deviceCard,
                      selectedDevice === device.id && styles.deviceCardSelected,
                    ]}
                    onPress={() => setSelectedDevice(selectedDevice === device.id ? null : device.id)}
                  >
                    <View style={styles.deviceHeader}>
                      <View style={styles.deviceInfo}>
                        <Text style={styles.deviceName}>{device.name}</Text>
                        <Text style={styles.deviceType}>{device.type}</Text>
                        <Text style={styles.deviceLocation}>{device.location}</Text>
                      </View>
                      <View style={styles.deviceStatus}>
                        <MaterialIcons
                          name={getStatusIcon(device.status) as any}
                          size={20}
                          color={getStatusColor(device.status)}
                        />
                        <Text style={[styles.statusText, { color: getStatusColor(device.status) }]}>
                          {device.status.charAt(0).toUpperCase() + device.status.slice(1)}
                        </Text>
                      </View>
                    </View>

                    <View style={styles.deviceMetrics}>
                      <View style={styles.metricItem}>
                        <Text style={styles.metricLabel}>Current Reading</Text>
                        <Text style={styles.metricValue}>{device.currentReading} kWh</Text>
                      </View>
                      <View style={styles.metricItem}>
                        <Text style={styles.metricLabel}>Last Update</Text>
                        <Text style={styles.metricValue}>{device.lastUpdate}</Text>
                      </View>
                    </View>

                    {selectedDevice === device.id && (
                      <View style={styles.deviceActions}>
                        <TouchableOpacity
                          style={[styles.actionButton, styles.enableButton]}
                          onPress={() => handleDeviceToggle(device.id, !device.enabled)}
                        >
                          <MaterialIcons
                            name={device.enabled ? 'pause' : 'play-arrow'}
                            size={16}
                            color="#ffffff"
                          />
                          <Text style={styles.actionButtonText}>
                            {device.enabled ? 'Disable' : 'Enable'}
                          </Text>
                        </TouchableOpacity>
                        <TouchableOpacity style={[styles.actionButton, styles.configButton]}>
                          <MaterialIcons name="settings" size={16} color="#ffffff" />
                          <Text style={styles.actionButtonText}>Configure</Text>
                        </TouchableOpacity>
                        <TouchableOpacity style={[styles.actionButton, styles.calibrateButton]}>
                          <MaterialIcons name="tune" size={16} color="#ffffff" />
                          <Text style={styles.actionButtonText}>Calibrate</Text>
                        </TouchableOpacity>
                      </View>
                    )}
                  </TouchableOpacity>
                ))}
              </View>
            </>
          )}
        </ScrollView>
      </LinearGradient>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  gradient: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#334155',
  },
  backButton: {
    padding: 8,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  addButton: {
    padding: 8,
  },
  scrollContent: {
    padding: 20,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
    paddingVertical: 60,
  },
  loadingText: {
    fontSize: 16,
    color: '#94a3b8',
  },
  summaryContainer: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 20,
  },
  summaryCard: {
    backgroundColor: '#1e293b',
    borderRadius: 12,
    padding: 16,
    width: (width - 60) / 3,
    alignItems: 'center',
  },
  summaryValue: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ffffff',
    marginTop: 8,
    marginBottom: 4,
  },
  summaryLabel: {
    fontSize: 10,
    color: '#94a3b8',
  },
  deviceList: {
    marginBottom: 20,
  },
  deviceCard: {
    backgroundColor: '#1e293b',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
    borderWidth: 1,
    borderColor: '#334155',
  },
  deviceCardSelected: {
    borderColor: '#3b82f6',
  },
  deviceHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 12,
  },
  deviceInfo: {
    flex: 1,
  },
  deviceName: {
    fontSize: 16,
    fontWeight: 'bold',
    color: '#ffffff',
    marginBottom: 4,
  },
  deviceType: {
    fontSize: 12,
    color: '#94a3b8',
    marginBottom: 2,
  },
  deviceLocation: {
    fontSize: 10,
    color: '#64748b',
  },
  deviceStatus: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  statusText: {
    fontSize: 10,
    fontWeight: '500',
    marginLeft: 4,
  },
  deviceMetrics: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  metricItem: {
    flex: 1,
  },
  metricLabel: {
    fontSize: 10,
    color: '#94a3b8',
    marginBottom: 4,
  },
  metricValue: {
    fontSize: 12,
    color: '#ffffff',
    fontWeight: '500',
  },
  deviceActions: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 12,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: '#334155',
  },
  actionButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderRadius: 6,
    flex: 1,
    marginHorizontal: 2,
    justifyContent: 'center',
  },
  enableButton: {
    backgroundColor: '#22c55e',
  },
  configButton: {
    backgroundColor: '#3b82f6',
  },
  calibrateButton: {
    backgroundColor: '#f59e0b',
  },
  actionButtonText: {
    fontSize: 10,
    color: '#ffffff',
    marginLeft: 4,
  },
});