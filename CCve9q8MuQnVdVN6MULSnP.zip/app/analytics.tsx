// Powered by OnSpace.AI
import React, { useState, useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, Dimensions } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { LinearGradient } from 'expo-linear-gradient';
import { MaterialIcons, Ionicons } from '@expo/vector-icons';
import { LineChart, BarChart } from 'react-native-chart-kit';
import { router } from 'expo-router';
import { getAnalyticsData } from '../services/energyService';

const { width } = Dimensions.get('window');

const viewTabs = [
  { id: 'matrix', title: 'Matrix View', icon: 'view-module' },
  { id: 'demand', title: 'Demand View', icon: 'trending-up' },
  { id: 'scada', title: 'Scada View', icon: 'settings' },
  { id: 'device', title: 'Device View', icon: 'devices' },
  { id: 'graph', title: 'Graph View', icon: 'show-chart' },
  { id: 'tabular', title: 'Tabular View', icon: 'table-chart' },
];

export default function Analytics() {
  const [selectedView, setSelectedView] = useState('matrix');
  const [analyticsData, setAnalyticsData] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const data = await getAnalyticsData();
        setAnalyticsData(data);
      } catch (error) {
        console.error('Failed to fetch analytics data:', error);
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const chartConfig = {
    backgroundGradientFrom: '#1e3a8a',
    backgroundGradientTo: '#3b82f6',
    color: (opacity = 1) => `rgba(255, 255, 255, ${opacity})`,
    strokeWidth: 2,
    barPercentage: 0.7,
    useShadowColorFromDataset: false,
  };

  const benchmarkData = {
    labels: ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10'],
    datasets: [
      {
        data: [100, 100, 100, 100, 100, 100, 100, 100, 100, 100],
        color: (opacity = 1) => `rgba(239, 68, 68, ${opacity})`,
        strokeWidth: 2,
      },
      {
        data: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
        color: (opacity = 1) => `rgba(34, 197, 94, ${opacity})`,
        strokeWidth: 2,
      },
    ],
  };

  const consumptionData = {
    labels: ['Feb-01', 'Feb-02'],
    datasets: [
      {
        data: [300, 50],
        color: (opacity = 1) => `rgba(34, 197, 94, ${opacity})`,
        strokeWidth: 2,
      },
    ],
  };

  if (loading) {
    return (
      <SafeAreaView style={styles.container}>
        <LinearGradient colors={['#0f172a', '#1e293b']} style={styles.gradient}>
          <View style={styles.loadingContainer}>
            <Text style={styles.loadingText}>Loading Analytics...</Text>
          </View>
        </LinearGradient>
      </SafeAreaView>
    );
  }

  return (
    <SafeAreaView style={styles.container}>
      <LinearGradient colors={['#0f172a', '#1e293b']} style={styles.gradient}>
        <View style={styles.header}>
          <TouchableOpacity onPress={() => router.back()} style={styles.backButton}>
            <Ionicons name="arrow-back" size={24} color="#ffffff" />
          </TouchableOpacity>
          <Text style={styles.headerTitle}>Asset Analytics</Text>
          <View style={styles.headerActions}>
            <TouchableOpacity style={styles.actionButton}>
              <MaterialIcons name="settings" size={20} color="#ffffff" />
            </TouchableOpacity>
          </View>
        </View>

        <ScrollView horizontal showsHorizontalScrollIndicator={false} style={styles.tabsContainer}>
          {viewTabs.map((tab) => (
            <TouchableOpacity
              key={tab.id}
              style={[
                styles.tabButton,
                selectedView === tab.id && styles.tabButtonActive,
              ]}
              onPress={() => setSelectedView(tab.id)}
            >
              <MaterialIcons
                name={tab.icon as any}
                size={16}
                color={selectedView === tab.id ? '#ffffff' : '#94a3b8'}
              />
              <Text
                style={[
                  styles.tabText,
                  selectedView === tab.id && styles.tabTextActive,
                ]}
              >
                {tab.title}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>

        <ScrollView contentContainerStyle={styles.scrollContent}>
          <View style={styles.summaryContainer}>
            <View style={styles.summaryCard}>
              <Text style={styles.summaryTitle}>This Month</Text>
              <Text style={styles.summaryLabel}>Energy Consumption</Text>
              <Text style={styles.summaryValue}>Total: 0.00 kWh Imp</Text>
            </View>
            <View style={styles.summaryCard}>
              <Text style={styles.summaryTitle}>Hourly Energy Consumption</Text>
              <Text style={styles.summaryValue}>Total: 0.00 kWh Imp</Text>
            </View>
          </View>

          <View style={styles.chartContainer}>
            <View style={styles.chartHeader}>
              <Text style={styles.chartTitle}>Benchmark for Last 24 Hours</Text>
              <View style={styles.chartControls}>
                <TouchableOpacity style={styles.controlButton}>
                  <Text style={styles.controlButtonText}>100</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.controlButton}>
                  <Text style={styles.controlButtonText}>P.F</Text>
                </TouchableOpacity>
                <TouchableOpacity style={styles.controlButton}>
                  <Text style={styles.controlButtonText}>Set</Text>
                </TouchableOpacity>
              </View>
            </View>
            <Text style={styles.chartSubtitle}>Meter2</Text>
            <LineChart
              data={benchmarkData}
              width={width - 40}
              height={220}
              chartConfig={chartConfig}
              style={styles.chart}
            />
            <View style={styles.chartLegend}>
              <View style={styles.legendItem}>
                <View style={[styles.legendColor, { backgroundColor: '#ef4444' }]} />
                <Text style={styles.legendText}>BenchValue</Text>
              </View>
              <View style={styles.legendItem}>
                <View style={[styles.legendColor, { backgroundColor: '#22c55e' }]} />
                <Text style={styles.legendText}>P.F</Text>
              </View>
            </View>
          </View>

          <View style={styles.chartContainer}>
            <View style={styles.chartHeader}>
              <Text style={styles.chartTitle}>Hourly Energy Consumption</Text>
              <Text style={styles.chartSubtitle}>Total: 0.00 kWh Imp</Text>
            </View>
            <BarChart
              data={consumptionData}
              width={width - 40}
              height={220}
              chartConfig={chartConfig}
              style={styles.chart}
            />
            <View style={styles.chartLegend}>
              <View style={styles.legendItem}>
                <View style={[styles.legendColor, { backgroundColor: '#22c55e' }]} />
                <Text style={styles.legendText}>Consumption</Text>
              </View>
              <View style={styles.legendItem}>
                <View style={[styles.legendColor, { backgroundColor: '#ef4444' }]} />
                <Text style={styles.legendText}>Cost</Text>
              </View>
            </View>
          </View>
        </ScrollView>
      </LinearGradient>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  gradient: {
    flex: 1,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: '#334155',
  },
  backButton: {
    padding: 8,
  },
  headerTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    color: '#ffffff',
  },
  headerActions: {
    flexDirection: 'row',
  },
  actionButton: {
    padding: 8,
  },
  tabsContainer: {
    maxHeight: 60,
    paddingHorizontal: 20,
    paddingVertical: 10,
  },
  tabButton: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 8,
    marginRight: 12,
    backgroundColor: '#1e293b',
    borderRadius: 20,
  },
  tabButtonActive: {
    backgroundColor: '#3b82f6',
  },
  tabText: {
    fontSize: 12,
    color: '#94a3b8',
    marginLeft: 6,
  },
  tabTextActive: {
    color: '#ffffff',
  },
  scrollContent: {
    padding: 20,
  },
  summaryContainer: {
    marginBottom: 20,
  },
  summaryCard: {
    backgroundColor: '#1e293b',
    borderRadius: 12,
    padding: 16,
    marginBottom: 12,
  },
  summaryTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#ffffff',
    marginBottom: 4,
  },
  summaryLabel: {
    fontSize: 12,
    color: '#94a3b8',
    marginBottom: 8,
  },
  summaryValue: {
    fontSize: 14,
    color: '#ffffff',
  },
  chartContainer: {
    backgroundColor: '#1e293b',
    borderRadius: 12,
    padding: 16,
    marginBottom: 20,
  },
  chartHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  chartTitle: {
    fontSize: 14,
    fontWeight: '600',
    color: '#ffffff',
  },
  chartSubtitle: {
    fontSize: 12,
    color: '#94a3b8',
    marginBottom: 16,
  },
  chartControls: {
    flexDirection: 'row',
  },
  controlButton: {
    backgroundColor: '#374151',
    paddingHorizontal: 12,
    paddingVertical: 4,
    borderRadius: 4,
    marginLeft: 4,
  },
  controlButtonText: {
    fontSize: 10,
    color: '#ffffff',
  },
  chart: {
    borderRadius: 8,
  },
  chartLegend: {
    flexDirection: 'row',
    justifyContent: 'center',
    marginTop: 12,
  },
  legendItem: {
    flexDirection: 'row',
    alignItems: 'center',
    marginHorizontal: 12,
  },
  legendColor: {
    width: 12,
    height: 12,
    borderRadius: 6,
    marginRight: 6,
  },
  legendText: {
    fontSize: 10,
    color: '#94a3b8',
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  loadingText: {
    fontSize: 16,
    color: '#ffffff',
  },
});