// Powered by OnSpace.AI
import { DashboardData } from './types';

export const getDashboardData = async (): Promise<DashboardData> => {
  try {
    // Simulating API call with real-time dashboard data
    await new Promise(resolve => setTimeout(resolve, 800));
    
    const currentTime = new Date();
    
    return {
      currentTime: currentTime.toISOString(),
      stationSchedule: 0,
      stationExBus: -0.15,
      stationAvgExBus: -0.15,
      avgFrequency: 49.89,
      avgDsmRate: 0,
      blockInfo: {
        blockNo: 66,
        timeRange: '16:15 - 16:30',
        timeElapsed: '10:22',
        timeRemaining: '4:38',
        realTimeApc: 0.00,
        realTimeApcPercent: 0.00,
        currentSgStatus: 0.00,
        avgSgStatus: 0.00,
      },
      frequencyTrend: {
        avgFreqOfBlock: 49.89,
        currentFreq: 49.89,
        last4MinAvg: 49.89,
        forecastFreq: 49.89,
        breakEvenHz: 49.89,
      },
      meterStatus: {
        meterName: 'ABT',
        lastStatus: '1 Min',
        currentLoad: -0.15,
        suggestions: 'Maintain Load 0.15 To Meet 100% of Schedule (0 kW )And Your Present Injection is Infinity%',
      },
      targetSchedule: {
        r6: 100,
        twelve: 12,
        eightyEight: 88,
        estimatedEnergy: 0.00,
        energyGenerated: 0.00,
        overInjection: 0.00,
        underInjection: 0.00,
        penalty: 0.00,
        receive: 0.00,
        netUi: '--',
      },
      dataTable: [
        {
          blockTime: '10-07-2025 16:15:00',
          blockNo: 66,
          se: 0.00,
          ae: 0.24,
          kwhSch: 0.00,
          kwhExp: 0.00,
          uiUnits: 0.00,
          hz: 49.93,
          uiRate: 0.00,
          uiAmt: 0.00,
        },
        {
          blockTime: '10-07-2025 16:00:00',
          blockNo: 65,
          se: 0.00,
          ae: 0.22,
          kwhSch: 0.00,
          kwhExp: 0.00,
          uiUnits: 0.00,
          hz: 50.05,
          uiRate: 0.00,
          uiAmt: 0.00,
        },
        {
          blockTime: '10-07-2025 15:45:00',
          blockNo: 64,
          se: 0.00,
          ae: 0.22,
          kwhSch: 0.00,
          kwhExp: 0.00,
          uiUnits: 0.00,
          hz: 50.03,
          uiRate: 0.00,
          uiAmt: 0.00,
        },
        // ... more data entries would continue here
      ],
    };
  } catch (error) {
    console.error('Failed to fetch dashboard data:', error);
    throw new Error('Unable to fetch dashboard data');
  }
};

export const getRealtimeUpdates = async (): Promise<any> => {
  try {
    // Simulating real-time data updates
    await new Promise(resolve => setTimeout(resolve, 200));
    
    return {
      currentTime: new Date().toISOString(),
      frequency: 49.85 + Math.random() * 0.1,
      currentLoad: -0.15 + Math.random() * 0.05,
      blockProgress: Math.random() * 100,
    };
  } catch (error) {
    console.error('Failed to fetch real-time updates:', error);
    throw new Error('Unable to fetch real-time updates');
  }
};