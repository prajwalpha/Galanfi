// Powered by OnSpace.AI
import { ApiResponse, PaginatedResponse, FilterOptions } from './types';

export const API_BASE_URL = 'https://api.your-energy-platform.com/v1';

export const API_ENDPOINTS = {
  // Authentication
  LOGIN: '/auth/login',
  LOGOUT: '/auth/logout',
  REFRESH: '/auth/refresh',
  
  // User Management
  USER_PROFILE: '/users/profile',
  UPDATE_PROFILE: '/users/profile',
  CHANGE_PASSWORD: '/users/change-password',
  EXPORT_DATA: '/users/export-data',
  
  // Energy Data
  ASSET_OVERVIEW: '/energy/overview',
  ANALYTICS: '/energy/analytics',
  REPORTS: '/energy/reports',
  METRICS: '/energy/metrics',
  
  // Device Management
  DEVICES: '/devices',
  DEVICE_STATUS: '/devices/status',
  DEVICE_READINGS: '/devices/readings',
  
  // Settings
  SETTINGS: '/settings',
  PREFERENCES: '/settings/preferences',
  NOTIFICATIONS: '/settings/notifications'
};

export const DEFAULT_HEADERS = {
  'Content-Type': 'application/json',
  'Accept': 'application/json'
};

export const getAuthHeaders = (): Record<string, string> => {
  // In a real implementation, this would retrieve the token from secure storage
  const token = 'YOUR_ACCESS_TOKEN_HERE';
  return {
    ...DEFAULT_HEADERS,
    'Authorization': `Bearer ${token}`
  };
};

export const apiRequest = async <T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<ApiResponse<T>> => {
  try {
    const url = `${API_BASE_URL}${endpoint}`;
    const config: RequestInit = {
      ...options,
      headers: {
        ...getAuthHeaders(),
        ...options.headers
      }
    };

    const response = await fetch(url, config);
    
    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    return {
      success: true,
      data,
      message: 'Request successful'
    };
  } catch (error) {
    console.error('API Request Error:', error);
    return {
      success: false,
      data: null as T,
      error: error instanceof Error ? error.message : 'Unknown error occurred'
    };
  }
};

export const paginatedRequest = async <T>(
  endpoint: string,
  page: number = 1,
  limit: number = 10,
  filters?: FilterOptions
): Promise<ApiResponse<PaginatedResponse<T>>> => {
  try {
    const searchParams = new URLSearchParams({
      page: page.toString(),
      limit: limit.toString(),
      ...filters
    });

    const url = `${API_BASE_URL}${endpoint}?${searchParams}`;
    const response = await fetch(url, {
      headers: getAuthHeaders()
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    return {
      success: true,
      data,
      message: 'Request successful'
    };
  } catch (error) {
    console.error('Paginated API Request Error:', error);
    return {
      success: false,
      data: null as PaginatedResponse<T>,
      error: error instanceof Error ? error.message : 'Unknown error occurred'
    };
  }
};

export const uploadFile = async (
  endpoint: string,
  file: File | Blob,
  additionalData?: Record<string, any>
): Promise<ApiResponse<any>> => {
  try {
    const formData = new FormData();
    formData.append('file', file);
    
    if (additionalData) {
      Object.entries(additionalData).forEach(([key, value]) => {
        formData.append(key, value);
      });
    }

    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer YOUR_ACCESS_TOKEN_HERE`
      },
      body: formData
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const data = await response.json();
    return {
      success: true,
      data,
      message: 'File uploaded successfully'
    };
  } catch (error) {
    console.error('File Upload Error:', error);
    return {
      success: false,
      data: null,
      error: error instanceof Error ? error.message : 'File upload failed'
    };
  }
};

export const downloadFile = async (
  endpoint: string,
  filename?: string
): Promise<ApiResponse<Blob>> => {
  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      headers: getAuthHeaders()
    });

    if (!response.ok) {
      throw new Error(`HTTP error! status: ${response.status}`);
    }

    const blob = await response.blob();
    
    // Trigger download if filename is provided
    if (filename) {
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      window.URL.revokeObjectURL(url);
    }

    return {
      success: true,
      data: blob,
      message: 'File downloaded successfully'
    };
  } catch (error) {
    console.error('File Download Error:', error);
    return {
      success: false,
      data: null as Blob,
      error: error instanceof Error ? error.message : 'File download failed'
    };
  }
};