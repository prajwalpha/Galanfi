// Powered by OnSpace.AI
export interface EnergyData {
  id: string;
  name: string;
  consumption: number;
  cost: number;
  unit: string;
  trend: 'up' | 'down' | 'stable';
  changePercent: number;
}

export interface Meter {
  id: string;
  name: string;
  type: string;
  consumption: number;
  cost: number;
  status: 'active' | 'inactive' | 'error';
}

export interface AssetOverview {
  todayConsumption: number;
  thisMonthConsumption: number;
  todayCost: number;
  thisMonthCost: number;
  yesterdayConsumption: number;
  yesterdayCost: number;
  forecastCost: number;
  lastMonthConsumption: number;
  lastMonthCost: number;
  lifetimeCost: number;
  meters: Meter[];
}

export interface BenchmarkData {
  labels: string[];
  values: number[];
  pfValues: number[];
}

export interface ConsumptionData {
  labels: string[];
  consumption: number[];
  cost: number[];
}

export interface AnalyticsData {
  benchmarkData: BenchmarkData;
  consumptionData: ConsumptionData;
  thisMonthTotal: number;
  hourlyTotal: number;
}

export interface ReportEntry {
  date: string;
  consumption: number;
  cost: number;
  efficiency: number;
}

export interface ChartData {
  labels: string[];
  consumption: number[];
  cost: number[];
}

export interface ReportSummary {
  totalConsumption: number;
  totalCost: number;
  consumptionChange: number;
  costChange: number;
}

export interface ReportsData {
  tableData: ReportEntry[];
  chartData: ChartData;
  summary: ReportSummary;
}

export interface UserProfile {
  id: string;
  name: string;
  email: string;
  phone: string;
  role: string;
  department: string;
  accessLevel: string;
  lastLogin: string;
  language: string;
  timezone: string;
  theme: string;
  avatar: string;
  createdAt: string;
  updatedAt: string;
}

export interface Device {
  id: string;
  name: string;
  status: 'online' | 'offline' | 'error';
  lastReading: string;
  location: string;
  type?: string;
}

export interface ApiResponse<T> {
  success: boolean;
  data: T;
  message?: string;
  error?: string;
}

export interface PaginatedResponse<T> {
  data: T[];
  total: number;
  page: number;
  limit: number;
  totalPages: number;
}

export interface FilterOptions {
  startDate?: string;
  endDate?: string;
  meterId?: string;
  deviceType?: string;
  status?: string;
}

export interface ChartOptions {
  type: 'line' | 'bar' | 'pie';
  timeRange: 'day' | 'week' | 'month' | 'year';
  metrics: string[];
}

export type TimeInterval = '15min' | '30min' | '60min' | 'daily' | 'weekly' | 'monthly' | 'yearly';

export interface ConsumptionReport {
  interval: TimeInterval;
  period: string;
  dataPoints: number;
  totalConsumption: number;
  totalCost: number;
  avgConsumption: number;
  peakConsumption: number;
  avgCostPerKwh: number;
  chartData: {
    labels: string[];
    consumption: number[];
    cost: number[];
  };
  summary: {
    totalConsumption: number;
    totalCost: number;
    consumptionChange: number;
    costChange: number;
  };
}

export interface EnergyTrendsData {
  totalConsumption: number;
  totalCost: number;
  efficiency: number;
  consumptionChange: number;
  costChange: number;
  efficiencyChange: number;
  hourlyData: {
    labels: string[];
    consumption: number[];
  };
  consumptionBySource: {
    electricity: number;
    gas: number;
    water: number;
  };
  peakHours: {
    labels: string[];
    values: number[];
  };
  insights: string[];
}

export interface DeviceInfo {
  id: string;
  name: string;
  type: string;
  location: string;
  status: 'online' | 'offline' | 'maintenance';
  enabled: boolean;
  currentReading: number;
  lastUpdate: string;
  batteryLevel: number;
  signalStrength: string;
  firmwareVersion: string;
  installationDate: string;
}

export interface BlockInfo {
  blockNo: number;
  timeRange: string;
  timeElapsed: string;
  timeRemaining: string;
  realTimeApc: number;
  realTimeApcPercent: number;
  currentSgStatus: number;
  avgSgStatus: number;
}

export interface FrequencyTrend {
  avgFreqOfBlock: number;
  currentFreq: number;
  last4MinAvg: number;
  forecastFreq: number;
  breakEvenHz: number;
}

export interface MeterStatus {
  meterName: string;
  lastStatus: string;
  currentLoad: number;
  suggestions: string;
}

export interface TargetSchedule {
  r6: number;
  twelve: number;
  eightyEight: number;
  estimatedEnergy: number;
  energyGenerated: number;
  overInjection: number;
  underInjection: number;
  penalty: number;
  receive: number;
  netUi: string;
}

export interface DataTableEntry {
  blockTime: string;
  blockNo: number;
  se: number;
  ae: number;
  kwhSch: number;
  kwhExp: number;
  uiUnits: number;
  hz: number;
  uiRate: number;
  uiAmt: number;
}

export interface DashboardData {
  currentTime: string;
  stationSchedule: number;
  stationExBus: number;
  stationAvgExBus: number;
  avgFrequency: number;
  avgDsmRate: number;
  blockInfo: BlockInfo;
  frequencyTrend: FrequencyTrend;
  meterStatus: MeterStatus;
  targetSchedule: TargetSchedule;
  dataTable: DataTableEntry[];
}