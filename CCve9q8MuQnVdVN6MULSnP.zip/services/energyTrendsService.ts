// Powered by OnSpace.AI
import { EnergyTrendsData } from './types';

export const getEnergyTrends = async (period: string): Promise<EnergyTrendsData> => {
  try {
    // Simulating API call with mock data
    await new Promise(resolve => setTimeout(resolve, 800));
    
    const generateTrendsData = (period: string) => {
      const now = new Date();
      let labels: string[] = [];
      let consumption: number[] = [];
      
      switch (period) {
        case 'today':
          labels = Array.from({ length: 24 }, (_, i) => `${String(i).padStart(2, '0')}:00`);
          consumption = Array.from({ length: 24 }, () => Math.random() * 100 + 20);
          break;
        case 'week':
          labels = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
          consumption = Array.from({ length: 7 }, () => Math.random() * 1000 + 200);
          break;
        case 'month':
          labels = Array.from({ length: 30 }, (_, i) => `${i + 1}`);
          consumption = Array.from({ length: 30 }, () => Math.random() * 1000 + 200);
          break;
        case 'year':
          labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
          consumption = Array.from({ length: 12 }, () => Math.random() * 10000 + 2000);
          break;
      }
      
      return { labels, consumption };
    };
    
    const hourlyData = generateTrendsData(period);
    const totalConsumption = hourlyData.consumption.reduce((sum, val) => sum + val, 0);
    
    return {
      totalConsumption,
      totalCost: totalConsumption * 6.25,
      efficiency: 85 + Math.random() * 15,
      consumptionChange: Math.random() * 20 - 10,
      costChange: Math.random() * 15 - 7.5,
      efficiencyChange: Math.random() * 10 - 5,
      hourlyData,
      consumptionBySource: {
        electricity: Math.random() * 60 + 20,
        gas: Math.random() * 30 + 10,
        water: Math.random() * 20 + 5,
      },
      peakHours: {
        labels: ['09:00', '12:00', '15:00', '18:00', '21:00'],
        values: Array.from({ length: 5 }, () => Math.random() * 200 + 100),
      },
      insights: [
        'Peak consumption occurs between 18:00-21:00 daily',
        'Energy efficiency has improved by 5% this month',
        'Weekend consumption is 15% lower than weekdays',
        'Consider implementing time-based energy scheduling',
        'Water heating accounts for 25% of total consumption',
      ],
    };
  } catch (error) {
    console.error('Failed to fetch energy trends:', error);
    throw new Error('Unable to fetch energy trends');
  }
};