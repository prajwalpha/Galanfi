// Powered by OnSpace.AI
import { ConsumptionReport, TimeInterval } from './types';

export const getConsumptionReports = async (interval: TimeInterval): Promise<ConsumptionReport> => {
  try {
    // Simulating API call with mock data based on interval
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const generateMockData = (interval: TimeInterval) => {
      const now = new Date();
      let labels: string[] = [];
      let consumption: number[] = [];
      let cost: number[] = [];
      
      switch (interval) {
        case '15min':
          labels = Array.from({ length: 24 }, (_, i) => {
            const time = new Date(now.getTime() - (23 - i) * 15 * 60 * 1000);
            return time.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
          });
          consumption = Array.from({ length: 24 }, () => Math.random() * 50 + 10);
          cost = consumption.map(c => c * 6.25);
          break;
        case '30min':
          labels = Array.from({ length: 24 }, (_, i) => {
            const time = new Date(now.getTime() - (23 - i) * 30 * 60 * 1000);
            return time.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
          });
          consumption = Array.from({ length: 24 }, () => Math.random() * 100 + 20);
          cost = consumption.map(c => c * 6.25);
          break;
        case '60min':
          labels = Array.from({ length: 24 }, (_, i) => {
            const time = new Date(now.getTime() - (23 - i) * 60 * 60 * 1000);
            return time.toLocaleTimeString('en-US', { hour: '2-digit' });
          });
          consumption = Array.from({ length: 24 }, () => Math.random() * 200 + 50);
          cost = consumption.map(c => c * 6.25);
          break;
        case 'daily':
          labels = Array.from({ length: 30 }, (_, i) => {
            const date = new Date(now.getTime() - (29 - i) * 24 * 60 * 60 * 1000);
            return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' });
          });
          consumption = Array.from({ length: 30 }, () => Math.random() * 1000 + 200);
          cost = consumption.map(c => c * 6.25);
          break;
        case 'weekly':
          labels = Array.from({ length: 12 }, (_, i) => `Week ${i + 1}`);
          consumption = Array.from({ length: 12 }, () => Math.random() * 5000 + 1000);
          cost = consumption.map(c => c * 6.25);
          break;
        case 'monthly':
          labels = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
          consumption = Array.from({ length: 12 }, () => Math.random() * 20000 + 5000);
          cost = consumption.map(c => c * 6.25);
          break;
        case 'yearly':
          labels = Array.from({ length: 5 }, (_, i) => `${2020 + i}`);
          consumption = Array.from({ length: 5 }, () => Math.random() * 200000 + 50000);
          cost = consumption.map(c => c * 6.25);
          break;
      }
      
      return { labels, consumption, cost };
    };
    
    const mockData = generateMockData(interval);
    const totalConsumption = mockData.consumption.reduce((sum, val) => sum + val, 0);
    const totalCost = mockData.cost.reduce((sum, val) => sum + val, 0);
    
    return {
      interval,
      period: `${interval} - ${new Date().toLocaleDateString()}`,
      dataPoints: mockData.labels.length,
      totalConsumption,
      totalCost,
      avgConsumption: totalConsumption / mockData.labels.length,
      peakConsumption: Math.max(...mockData.consumption),
      avgCostPerKwh: totalCost / totalConsumption,
      chartData: mockData,
      summary: {
        totalConsumption,
        totalCost,
        consumptionChange: Math.random() * 20 - 10,
        costChange: Math.random() * 15 - 7.5,
      },
    };
  } catch (error) {
    console.error('Failed to fetch consumption reports:', error);
    throw new Error('Unable to fetch consumption reports');
  }
};

export const downloadReport = async (interval: TimeInterval, format: string): Promise<void> => {
  try {
    // Simulating file download
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // In a real implementation, this would:
    // 1. Call the API to generate the report
    // 2. Download the file
    // 3. Save it to the device
    
    console.log(`Downloading ${interval} report in ${format} format...`);
    
    // Mock successful download
    return Promise.resolve();
  } catch (error) {
    console.error('Failed to download report:', error);
    throw new Error('Unable to download report');
  }
};