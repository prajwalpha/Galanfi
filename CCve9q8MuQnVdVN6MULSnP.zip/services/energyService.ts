// Powered by OnSpace.AI
import { EnergyData, AssetOverview, AnalyticsData, ReportsData } from './types';

const API_BASE_URL = 'https://api.your-energy-platform.com/v1';

export const getAssetOverviewData = async (): Promise<AssetOverview> => {
  try {
    // Simulating API call with mock data
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    return {
      todayConsumption: 0.00,
      thisMonthConsumption: 0.00,
      todayCost: 0.00,
      thisMonthCost: 0.00,
      yesterdayConsumption: 51.14,
      yesterdayCost: 319.63,
      forecastCost: 320.72,
      lastMonthConsumption: 2679.59,
      lastMonthCost: 16747.44,
      lifetimeCost: 8904.63,
      meters: [
        {
          id: 'meter1',
          name: 'Meter1',
          type: 'Electricity',
          consumption: 0.00,
          cost: 0.00,
          status: 'active'
        }
      ]
    };
  } catch (error) {
    console.error('Failed to fetch asset overview data:', error);
    throw new Error('Unable to fetch asset overview data');
  }
};

export const getAnalyticsData = async (): Promise<AnalyticsData> => {
  try {
    // Simulating API call with mock data
    await new Promise(resolve => setTimeout(resolve, 800));
    
    return {
      benchmarkData: {
        labels: ['01', '02', '03', '04', '05', '06', '07', '08', '09', '10'],
        values: [100, 100, 100, 100, 100, 100, 100, 100, 100, 100],
        pfValues: [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
      },
      consumptionData: {
        labels: ['Feb-01', 'Feb-02'],
        consumption: [300, 50],
        cost: [320, 52]
      },
      thisMonthTotal: 0.00,
      hourlyTotal: 0.00
    };
  } catch (error) {
    console.error('Failed to fetch analytics data:', error);
    throw new Error('Unable to fetch analytics data');
  }
};

export const getReportsData = async (): Promise<ReportsData> => {
  try {
    // Simulating API call with mock data
    await new Promise(resolve => setTimeout(resolve, 1200));
    
    return {
      tableData: [
        {
          date: '2025-01-01',
          consumption: 125.50,
          cost: 780.50,
          efficiency: 92
        },
        {
          date: '2025-01-02',
          consumption: 130.20,
          cost: 810.25,
          efficiency: 89
        },
        {
          date: '2025-01-03',
          consumption: 118.75,
          cost: 738.90,
          efficiency: 95
        },
        {
          date: '2025-01-04',
          consumption: 142.30,
          cost: 885.85,
          efficiency: 87
        },
        {
          date: '2025-01-05',
          consumption: 128.60,
          cost: 800.15,
          efficiency: 91
        }
      ],
      chartData: {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        consumption: [120, 150, 180, 200, 160, 190],
        cost: [80, 100, 120, 140, 110, 130]
      },
      summary: {
        totalConsumption: 1247.85,
        totalCost: 7768.25,
        consumptionChange: 12.5,
        costChange: 8.3
      }
    };
  } catch (error) {
    console.error('Failed to fetch reports data:', error);
    throw new Error('Unable to fetch reports data');
  }
};

export const getEnergyMetrics = async (): Promise<EnergyData[]> => {
  try {
    // Simulating API call with mock data
    await new Promise(resolve => setTimeout(resolve, 600));
    
    return [
      {
        id: 'electricity',
        name: 'Electricity',
        consumption: 1247.85,
        cost: 7768.25,
        unit: 'kWh',
        trend: 'up',
        changePercent: 12.5
      },
      {
        id: 'gas',
        name: 'Natural Gas',
        consumption: 856.42,
        cost: 4521.18,
        unit: 'cubic meters',
        trend: 'down',
        changePercent: -3.2
      },
      {
        id: 'water',
        name: 'Water',
        consumption: 2843.67,
        cost: 1892.45,
        unit: 'liters',
        trend: 'up',
        changePercent: 8.1
      }
    ];
  } catch (error) {
    console.error('Failed to fetch energy metrics:', error);
    throw new Error('Unable to fetch energy metrics');
  }
};

export const getDeviceStatus = async (): Promise<any[]> => {
  try {
    // Simulating API call with mock data
    await new Promise(resolve => setTimeout(resolve, 500));
    
    return [
      {
        id: 'meter1',
        name: 'Main Electricity Meter',
        status: 'online',
        lastReading: new Date().toISOString(),
        location: 'Building A - Floor 1'
      },
      {
        id: 'meter2',
        name: 'Secondary Meter',
        status: 'online',
        lastReading: new Date().toISOString(),
        location: 'Building A - Floor 2'
      },
      {
        id: 'gas-meter1',
        name: 'Gas Meter',
        status: 'offline',
        lastReading: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
        location: 'Basement'
      }
    ];
  } catch (error) {
    console.error('Failed to fetch device status:', error);
    throw new Error('Unable to fetch device status');
  }
};