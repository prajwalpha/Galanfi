// Powered by OnSpace.AI
import { UserProfile } from './types';

const API_BASE_URL = 'https://api.your-energy-platform.com/v1';

export const getUserProfile = async (): Promise<UserProfile> => {
  try {
    // Simulating API call with mock data
    await new Promise(resolve => setTimeout(resolve, 800));
    
    return {
      id: 'EM-2025-001',
      name: 'John Doe',
      email: 'john.doe@company.com',
      phone: '+1 (555) 123-4567',
      role: 'Energy Manager',
      department: 'Energy Management',
      accessLevel: 'Administrator',
      lastLogin: 'Today, 09:30 AM',
      language: 'English',
      timezone: 'UTC+05:30',
      theme: 'Dark Mode',
      avatar: 'https://picsum.photos/seed/user-avatar/120/120.webp',
      createdAt: '2024-01-15T10:30:00Z',
      updatedAt: '2025-01-10T14:22:00Z'
    };
  } catch (error) {
    console.error('Failed to fetch user profile:', error);
    throw new Error('Unable to fetch user profile');
  }
};

export const updateUserProfile = async (profileData: Partial<UserProfile>): Promise<UserProfile> => {
  try {
    // Simulating API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // In a real implementation, this would send the update to the server
    const response = await fetch(`${API_BASE_URL}/users/profile`, {
      method: 'PUT',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer YOUR_ACCESS_TOKEN'
      },
      body: JSON.stringify(profileData)
    });
    
    if (!response.ok) {
      throw new Error('Failed to update profile');
    }
    
    return response.json();
  } catch (error) {
    console.error('Failed to update user profile:', error);
    throw new Error('Unable to update user profile');
  }
};

export const changePassword = async (currentPassword: string, newPassword: string): Promise<void> => {
  try {
    // Simulating API call
    await new Promise(resolve => setTimeout(resolve, 1200));
    
    const response = await fetch(`${API_BASE_URL}/users/change-password`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': 'Bearer YOUR_ACCESS_TOKEN'
      },
      body: JSON.stringify({
        currentPassword,
        newPassword
      })
    });
    
    if (!response.ok) {
      throw new Error('Failed to change password');
    }
  } catch (error) {
    console.error('Failed to change password:', error);
    throw new Error('Unable to change password');
  }
};

export const exportUserData = async (): Promise<Blob> => {
  try {
    // Simulating API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    const response = await fetch(`${API_BASE_URL}/users/export-data`, {
      method: 'GET',
      headers: {
        'Authorization': 'Bearer YOUR_ACCESS_TOKEN'
      }
    });
    
    if (!response.ok) {
      throw new Error('Failed to export data');
    }
    
    return response.blob();
  } catch (error) {
    console.error('Failed to export user data:', error);
    throw new Error('Unable to export user data');
  }
};

export const logout = async (): Promise<void> => {
  try {
    // Simulating API call
    await new Promise(resolve => setTimeout(resolve, 500));
    
    const response = await fetch(`${API_BASE_URL}/auth/logout`, {
      method: 'POST',
      headers: {
        'Authorization': 'Bearer YOUR_ACCESS_TOKEN'
      }
    });
    
    if (!response.ok) {
      throw new Error('Failed to logout');
    }
    
    // Clear local storage/session data
    // This would typically clear stored tokens
  } catch (error) {
    console.error('Failed to logout:', error);
    throw new Error('Unable to logout');
  }
};