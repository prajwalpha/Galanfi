// Powered by OnSpace.AI
import { DeviceInfo } from './types';

export const getDeviceList = async (): Promise<DeviceInfo[]> => {
  try {
    // Simulating API call with mock data
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    return [
      {
        id: 'device-001',
        name: 'Main Electricity Meter',
        type: 'Smart Meter',
        location: 'Building A - Floor 1',
        status: 'online',
        enabled: true,
        currentReading: 1247.85,
        lastUpdate: '2 minutes ago',
        batteryLevel: 95,
        signalStrength: 'Strong',
        firmwareVersion: '2.1.4',
        installationDate: '2023-06-15',
      },
      {
        id: 'device-002',
        name: 'Secondary Meter',
        type: 'Smart Meter',
        location: 'Building A - Floor 2',
        status: 'online',
        enabled: true,
        currentReading: 856.42,
        lastUpdate: '1 minute ago',
        batteryLevel: 88,
        signalStrength: 'Good',
        firmwareVersion: '2.1.4',
        installationDate: '2023-06-20',
      },
      {
        id: 'device-003',
        name: 'Gas Meter',
        type: 'Gas Monitor',
        location: 'Basement',
        status: 'maintenance',
        enabled: false,
        currentReading: 324.67,
        lastUpdate: '2 hours ago',
        batteryLevel: 45,
        signalStrength: 'Weak',
        firmwareVersion: '1.8.2',
        installationDate: '2023-05-10',
      },
      {
        id: 'device-004',
        name: 'Water Flow Meter',
        type: 'Water Monitor',
        location: 'Utility Room',
        status: 'online',
        enabled: true,
        currentReading: 2843.67,
        lastUpdate: '30 seconds ago',
        batteryLevel: 92,
        signalStrength: 'Strong',
        firmwareVersion: '3.0.1',
        installationDate: '2023-07-01',
      },
      {
        id: 'device-005',
        name: 'HVAC Monitor',
        type: 'Environmental Sensor',
        location: 'Building A - Rooftop',
        status: 'offline',
        enabled: true,
        currentReading: 0,
        lastUpdate: '6 hours ago',
        batteryLevel: 0,
        signalStrength: 'None',
        firmwareVersion: '1.5.3',
        installationDate: '2023-04-15',
      },
    ];
  } catch (error) {
    console.error('Failed to fetch device list:', error);
    throw new Error('Unable to fetch device list');
  }
};

export const updateDeviceSettings = async (deviceId: string, settings: Partial<DeviceInfo>): Promise<void> => {
  try {
    // Simulating API call
    await new Promise(resolve => setTimeout(resolve, 500));
    
    console.log(`Updating device ${deviceId} with settings:`, settings);
    
    // In a real implementation, this would send the update to the server
    return Promise.resolve();
  } catch (error) {
    console.error('Failed to update device settings:', error);
    throw new Error('Unable to update device settings');
  }
};

export const calibrateDevice = async (deviceId: string): Promise<void> => {
  try {
    // Simulating calibration process
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    console.log(`Calibrating device ${deviceId}...`);
    
    return Promise.resolve();
  } catch (error) {
    console.error('Failed to calibrate device:', error);
    throw new Error('Unable to calibrate device');
  }
};

export const getDeviceHistory = async (deviceId: string, days: number = 30): Promise<any[]> => {
  try {
    // Simulating API call with mock historical data
    await new Promise(resolve => setTimeout(resolve, 800));
    
    const history = Array.from({ length: days }, (_, i) => {
      const date = new Date();
      date.setDate(date.getDate() - (days - 1 - i));
      
      return {
        date: date.toISOString().split('T')[0],
        reading: Math.random() * 1000 + 500,
        consumption: Math.random() * 200 + 50,
        cost: Math.random() * 1000 + 200,
        efficiency: Math.random() * 20 + 80,
      };
    });
    
    return history;
  } catch (error) {
    console.error('Failed to fetch device history:', error);
    throw new Error('Unable to fetch device history');
  }
};